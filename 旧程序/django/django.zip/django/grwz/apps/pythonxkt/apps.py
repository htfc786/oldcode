from django.apps import AppConfig


class PythonxktConfig(AppConfig):
    name = 'apps.pythonxkt'
