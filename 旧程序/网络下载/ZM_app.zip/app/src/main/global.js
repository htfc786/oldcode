/**
 * 设置global全局变量
 */
const update = require("./update/update");
global.checkForUpdates = update.checkForUpdates;
global.checkUpdateState = update.checkUpdateState;