/**
 * 设置本地状态
 */
const { storage } = require('node-environment')
const { logDebug } = require('./log/index')
const { defaultStatus, statusCode } = require('../common/constants')
const { sendInfo } = require('./log/index')

async function setStatus(statusName, status, extra) {
  logDebug('setStatus: ', statusName, status, extra)
  const data = storage.getItem(statusName)
  if (data && data.extra) {
    extra = Object.assign({}, data.extra, extra)
  }
  return storage.setItem({
    [statusName]: {
      status: status,
      extra: extra
    }
  })
}

async function getStatus(statusName, status, extra) {
  extra = extra || {}
  const data = typeof status !== 'undefined' && status !== null ?
    { status, extra } :
    (defaultStatus[statusName] ? defaultStatus[statusName] : null)
  logDebug('getStatus-data: ', data)
  return data ? storage.getItem(statusName, data) : storage.getItem(statusName)
}

async function virtualBgStatusStrategy() {
  const data = await getStatus(statusCode.VIRTUAL_BG_STATUS)
  if (data.status === 1) {
    setStatus(statusCode.VIRTUAL_BG_STATUS, -1)
    sendInfo('set-virtual-success', '设置虚拟背景状态为-1')
  }
}

function getData(name) {
  return storage.getItem(name)
}

function setData(name, value) {
  return storage.setItem({ [name]: value })
}

module.exports = {
  setStatus,
  getStatus,
  getData,
  setData,
  virtualBgStatusStrategy
}