/**
 * 处理原生调用崩溃问题
 * 1. recordNativeApiCall：提供web端通知调用原生api ，push进内存调用队列（调用队列是内存记录，不写本地只记录当前客户端生命周期）
 * 2. recordNativeApiWhenCrash：如有崩溃从native调用队列取出10秒内崩溃的调用函数，生成崩溃记录写入本地数据，单独写崩溃文件即可（fs），格式如下 {crashNativeApi: 'getDeviceInfo', crashInfo: [{namespace,level,url,crashTime}]}
 * 3. getNativeApiCrashInfo：提供web端查询crash接口功能，返回数据{count: 2, crashInfo: [{namespace,level,url,crashTime}, {namespace,level,url,crashTime}]}
 */

const RendererEmitter = require('../ipc/ipc-preload')
const emitter = new RendererEmitter('preloadJs')

/**
 * 调用原生api
 * @param {object} option 
 */
function recordNativeApiCall(option) {
  return emitter.ipcSend('recordNativeApiCall', option)
}

/**
 * 获取api崩溃信息
 * @param {string} apiName 
 */
function getNativeApiCrashInfo(apiName) {
  return emitter.ipcInvoke('getNativeApiCrashInfo', apiName)
}

module.exports = {
  recordNativeApiCall,
  getNativeApiCrashInfo
}