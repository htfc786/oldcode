/**
 * 兼容模式打开程序
 */

const { ipcMain, app } = require('electron')
const { spawn } = require('child_process');
const invokeLite = require("iconv-lite");
const { sendError, sendInfo } = require("./log/index");
const compatibilityPath = "HKCU\\Software\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatFlags\\Layers";
const exepath = app.getPath('exe')
const type = "REG_SZ"
const value = "~ WIN7RTM"
const WIN7RTM = 'WIN7RTM'

/**
 * 添加注册表
 * @param {String} regeditPath 
 * @param {String} name 
 * @param {String} type 
 * @param {String} value 
 */
function addRegedit(regeditPath, name, type, value) {
  return new Promise((resolve, reject) => {
    const childProcess = spawn("reg", ['add', regeditPath, '/v', name, '/t', type, '/d', value, '/f'])
    let { stdout, stderr } = childProcess
    stdout.on('end', function () {
      resolve()
    })
    stdout.on('error', function (err) {
      reject(err)
    })
    stderr.on('data', function (data) {
      reject(invokeLite.decode(data, 'gbk'))
    })
    stderr.on('error', function (error) {
      reject(error)
    })
    childProcess.on('error', function (err) {
      reject(err)
    })
  })
}


/**
 * 判断是否win7
 */
function isWin7() {
  const os = require('os')
  return os.release().startsWith('6.1')
}


/**
 * 获取某个注册表的值 
 * @param {String} regeditPath 
 * @param {String} name 
 */
function getRegedit(regeditPath, name) {
  return new Promise((resolve, reject) => {
    let chunks = []
    const childProcess = spawn("reg", ['query', regeditPath, '/v', name])
    let { stdout, stderr } = childProcess
    stdout.on('data', function (data) {
      chunks = chunks.concat(data)
    })
    stdout.on('end', function () {
      let buffer = Buffer.concat(chunks)
      resolve(invokeLite.decode(buffer, 'gbk'))
    })
    stderr.on('data', function () {
      resolve()
    })
    childProcess.on('error', function () {
      resolve()
    })
  })
}

/**
 * 删除注册表值
 * @param {String} regeditPath 
 * @param {String} name 
 */
function deleteRegedit(regeditPath, name) {
  return new Promise((resolve, reject) => {
    let chunks = []
    const childProcess = spawn("reg", ['delete', regeditPath, '/v', name, '/f'])
    let { stdout, stderr } = childProcess
    stdout.on('data', function (data) {
      chunks = chunks.concat(data)
    })
    stdout.on('end', function () {
      let buffer = Buffer.concat(chunks)
      resolve(invokeLite.decode(buffer, 'gbk'))
    })
    stdout.on('error', function (err) {
      reject(err)
    })
    stderr.on('data', function (data) {
      reject(invokeLite.decode(data, 'gbk'))
    })
    stderr.on('error', function (error) {
      reject(error)
    })
    childProcess.on('error', function (err) {
      reject(err)
    })
  })
}

async function isCompatibility() {
  const data = await getRegedit(compatibilityPath, exepath)
  return data ? data.includes(WIN7RTM) : false
}

async function run() {
  try {
    if (!isWin7()) return
    // 检测开启状态
    const status = await isCompatibility()
    sendInfo("win7-compatibility-status", `当前兼容模式为${status}`)
    if (!status) {
      await addRegedit(compatibilityPath, exepath, type, value)
      sendInfo("add-compatibility-status", "开启兼容模式成功")
    }
  } catch (err) {
    sendError("compatibility-error", "操作兼容模式失败", err)
  }
}


/**
 * 获取用户pc基本信息
 */
function baseComputerInfo() {
  // 用户基础性能数据
  const os = require('os')
  const platform = os.platform()
  const release = os.release()
  const memory = os.totalmem()
  const cpus = os.cpus()
  const arch = is32OR64()
  const si = require('systeminformation');
  // 存储本地
  sendInfo("base-pc-info", JSON.stringify({
    platform,
    release,
    cpus,
    memory,
    arch
  }, null, 2));
  si.graphics().then(data => {
    sendInfo('base-graphy-info', JSON.stringify(data, null, 2))
  });
}


function is32OR64() {
  if (process.env.PROCESSOR_ARCHITECTURE === 'AMD64') {
    return 64
  } else if (process.env.PROCESSOR_ARCHITEW6432 === 'AMD64') {
    return 64
  } else {
    return 32
  }
}


ipcMain.on("close-win7-compatibility", function () {
  // 关闭兼容模式
  deleteRegedit(compatibilityPath, exepath).catch((err) => {
    sendError("close-win7-compatibility-error", "关闭兼容模式失败", err)
  })
})



module.exports = {
  run,
  baseComputerInfo
}