/**
 * socket
 */
function createWs() {
  var tcpPortUsed = require("tcp-port-used");
  tcpPortUsed.check(5080, "localhost").then(
    function (inUse) {
      if (!inUse) {
        const WebSocket = require("ws");
        const wss = new WebSocket.Server({ port: 5080 });
        wss.on("connection", function connection(ws) {
          ws_server = ws;
          ws.on("message", function incoming(message) {
            ws.send(message);
          });
        });
      }
      console.log("Port 5080 usage: " + inUse);
    },
    function (err) {
      console.error("Error on check:", err.message);
    }
  );
}

module.exports = {
  createWs
}