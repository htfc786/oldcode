from django.urls import path
from .views import *

urlpatterns = [
    path("space/user/login/", login),
]

t = [
    ''
]