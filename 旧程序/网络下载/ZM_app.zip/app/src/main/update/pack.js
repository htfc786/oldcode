/**
 * 资源包基础操作api
 * 
 * 资源包结构（固定格式）
 * ---resource
 * | |
 * | |---app资源
 * |---change.json
 * 
 * api
 */

const path = require('path')
const fs = require('fs-extra')
const { download, unCompressResource } = require('../download')
const RunPack = require('./pack-adapter')



class Pack {
  constructor(config) {
    this.updatePath = config.updatePath
    this.rootPath = config.rootPath
    try {
      fs.ensureDirSync(this.updatePath)
    } catch (err) {
      console.log(err)
    }
  }

  /**
    * 执行一个资源包，并返回新的资源包（该包的备份包）的名称
    * @param {string} packageName 资源包名称
    * @return {string} backupPath 备份包的名称
    */
  executePackage(packageName) {
    // 生成备份包的地址
    let backPackageName = this.createNewPackageName()
    // 实例化执行包对象
    const runPack = new RunPack({
      updatePath: this.updatePath,
      rootPath: this.rootPath,
      backPackageName: backPackageName,
      packageName: packageName
    })
    runPack.run()
    // 删老包
    this.deletePackage(packageName)
    return backPackageName
  }

  /**
   * 删除资源包
   * @param {string} packageName 
   */
  deletePackage(packageName) {
    const packagePath = path.join(this.updatePath, packageName)
    fs.removeSync(packagePath)
  }

  /**
   * 给定一个资源包进行升级操作
   * @param {string} packageName 
   * @return {string} backPackageName 备份包名称
   */
  runAsUpdate(packageName) {
    // 执行一个包
    return this.executePackage(packageName)
  }



  /**
   * 给定一个资源包（备份包）进行回滚操作
   * @param {string} packageName 
   */
  runAsRollback(packageName) {
    let backPackageName = this.executePackage(packageName)
    this.deletePackage(backPackageName)
  }

  /**
   * 检测包是否存在
   * @param {string} packageName 
   */
  ifExist(packageName) {
    const packagePath = path.join(this.updatePath, packageName)
    return fs.existsSync(packagePath)
  }


  /**
   * 生成空包名
   */
  createNewPackageName() {
    const timeStamp = new Date().getTime();
    const list = [];
    list.push(timeStamp);
    list.push(
      Math.random()
        .toString()
        .substr(-4)
    );
    return list.join("");
  }

  /**
   * 下载并保存新的资源包
   * @param {object} option 下载时的url、sha512等参数
   * @return {string} savePackName 返回下载并解压成功的packageName
   */
  async downloadPackage(option) {
    const savePackName = this.createNewPackageName()
    const savePath = path.join(this.updatePath, 'update.tar.gz')
    const packagePath = path.join(this.updatePath, savePackName)
    // 下载
    await download({
      url: option.url,
      hash: option.sha512,
      savePath: savePath
    })
    // 解压
    await unCompressResource(savePath, packagePath)
    // 删除压缩包
    await fs.remove(savePath)
    return savePackName
  }
}

module.exports = Pack


