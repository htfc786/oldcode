/**
 * 埋点跟踪上报
 */

const path = require('path')
const Acc = require("node-acc");
const { app } = require("electron");
const { getDeviceId, getClientId, storage } = require("node-environment");
const userDataPath = app.getPath("userData");
const logPath = path.join(userDataPath, 'logs')
const saveDataPath = path.join(logPath, "acc_data.json");

const acc = new Acc({
  accUploadUrl: global.environment.accUrl,
  timeInterval: 5000,
  saveDataPath: saveDataPath
});

async function formatData(config) {
  const times = new Date().getTime();
  const deviceId = await getDeviceId().catch(err => '')
  const userId = storage.getItem('userId', 111111)
  const client = getClientId()
  const baseConfig = {
    aid: global.environment.appId,
    did: deviceId,
    device: client,
    tt: 5,
    appv: global.environment.version,
    sdkv: global.environment.resourceVersion,
    time: times,
    uid: userId,
    counter: 1
  }
  return Object.assign({}, config, baseConfig)
}

/**
 * 
 * @param {String} code 
 * @param {String} type 
 * @param {Object} msg 
 * @param {error} err 
 * @param {boolean} immediate 
 */
async function serverLog(code, msg, err, type, immediate) {
  try {
    const config = {
      lv: type || 'info',
      msg: msg,
      code: code,
      stack: err instanceof Error ? err.stack : err
    }
    const data = await formatData(config)
    return acc.send(data, immediate);
  } catch (err) { console.log(err) }
}

async function serverLogError(code, msg, err, immediate) {
  return serverLog(code, msg, err, 'error', immediate)
}

async function serverLogInfo(code, msg, immediate) {
  return serverLog(code, msg, '', 'info', immediate)
}

async function serverLogEvents(action, msg, immediate) {
  try {
    const config = {
      eid: action,
      ep: msg
    }
    const data = await formatData(config)
    return acc.send(data, immediate);
  } catch (err) { }
}

module.exports = {
  serverLog,
  serverLogError,
  serverLogInfo,
  serverLogEvents
}