/**
 * 崩溃日志
 */
async function crashReport() {
  const { ipcRenderer, crashReporter, remote } = require('electron')
  const { domain, version, resourceVersion } = remote.getGlobal('environment');
  const deviceId = await ipcRenderer.invoke('getDeviceId')
  crashReporter.start({
    companyName: "zmlearn",
    submitURL: `${domain}/gateway/zmc-monitor/api/fill/collapse`,
    ignoreSystemCrashHandler: true,
    extra: {
      appId: '10839',
      deviceId: deviceId,
      version: version,
      resourceVersion: resourceVersion,
    }
  });
}

module.exports = {
  crashReport
}