const path = require('path')
const { app, Menu, session } = require("electron");
const windowManager = require("electron-window-manager");
const { listAllInstallVersion } = require('./regedit')
const { sendError, sendInfo, logDebug } = require('./log/index')

function setMutex() {
  try {
    logDebug('开始设置程序锁')
    const { Mutex } = require('windows-mutex');
    const mutex = new Mutex(global.environment.appMutex);
    app.on('quit', function () {
      mutex.release();
      logDebug('程序锁释放')
    })
    logDebug('设置程序锁成功')
  } catch (err) {
    sendError("setMutexError", "设置程序锁出错！", err);
  }
}

function setSingleInstance() {
  logDebug('设置单例模式')
  const gotTheLock = app.requestSingleInstanceLock();
  // console.log(gotTheLock)
  if (!gotTheLock) {
    logDebug('触发单例模式关闭第二实例')
    app.quit();
    return false;
  } else {
    app.on("second-instance", (event, commandLine, workingDirectory) => {
      // 当运行第二个实例时,将会聚焦到myWindow这个窗口
      logDebug('将焦点聚焦到第一实例上')
      const win = windowManager.get("Login");
      if (win) {
        if (win.object && win.object.isMinimized()) win.object.restore();
        win.object.focus();
      }
    });
  }
  return true;
}

function setBaseConfig() {
  process.umask(0o000);
  app.commandLine.appendSwitch('js-flags', '--max-old-space-size=2048');
  app.commandLine.appendSwitch("ignore-certificate-errors");
  app.commandLine.appendSwitch("enable-webgl");
  app.commandLine.appendSwitch('disable-site-isolation-trials')
  process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
  Menu.setApplicationMenu(null)
  // 根据配置开启或关闭gpu加速
  const { getLocalGpuStrategy } = require('./gpu-strategy')
  const gpuStrategy = getLocalGpuStrategy()
  if (!gpuStrategy.state) {
    app.disableHardwareAcceleration()
    app.commandLine.appendSwitch("disable-gpu");
    app.commandLine.appendSwitch("ignore-gpu-blacklist");
  }
  // 记录本次gpu开启状态，防止被更新掉
  global.environment.gpuStrategyState = gpuStrategy.state
  sendInfo('gpuStrategyType', `当前gpu状态：${gpuStrategy.state}`)
}

function getRegeditInfo() {
  listAllInstallVersion()
    .then(list => {
      global.regeditList = list
      logDebug('获取已安装客户端信息', list)
    })
    .catch(err => {
      global.regeditList = []
      sendError('listAllInstallVersionError', '获取注册表失败', err)
    })
}

function localFontSize() {
  // 字体本地化
  sendInfo("openFontLocalization", "开启字体本地化！");
  session.defaultSession.webRequest.onBeforeRequest(
    {
      urls: ["*://*/*"]
    },
    (details, callback) => {
      const blackList = [
        "SourceHanSansCN-Regular.otf",
        "arial.ttf",
        "pinyin.ttf"
      ];
      const key = blackList.findIndex(
        item =>
          details.url.indexOf(item) > -1 &&
          details.url.indexOf("image") > -1 &&
          details.url.indexOf("file://") === -1
      );

      if (key > -1) {
        const redirectURL = path.join(
          "file://",
          global.environment.rootPath,
          "../",
          blackList[key]
        );
        callback({ cancel: false, redirectURL: redirectURL });
      } else {
        callback({ cancel: false });
      }
    }
  );
}



module.exports = {
  setMutex,
  setSingleInstance,
  setBaseConfig,
  getRegeditInfo,
  localFontSize
}