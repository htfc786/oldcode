from django.apps import AppConfig


class HomePageConfig(AppConfig):
    name = 'apps.home_page'
