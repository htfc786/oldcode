
const path = require('path')
const { app } = require("electron");
const childProcess = require('child_process')
const { serverLogError } = require('./tracking')

let child = null
const userDataPath = app.getPath("userData");
const logPath = path.join(userDataPath, 'logs')
const childPath = path.join(__dirname, './log-fork.js')
const logFolderPath = path.join(logPath, global.environment.logFolder)

function createChildProcess(times) {
  child = childProcess.fork(childPath, [logFolderPath])
  console.log('child.connected', child.connected)
  child.on('exit', function (code, signal) {
    console.log('child_process exit')
    serverLogError('log_process_exit', JSON.stringify({ code: code, signal: signal, times: times }))
    if (times < 3) {
      times++
      createChildProcess(times)
    }
  })
  child.on('error', function (err) {
    console.log('err', err)
    serverLogError('log_process_error', err.stack)
  })
}

createChildProcess(0)

function log(option) {
  try {
    option.msg = typeof option.msg === 'object' ? JSON.stringify(option.msg, null, 2) : option.msg
    if (child.connected) {
      child.send({
        logName: option.logName || 'log',
        model: option.model || 'main',
        type: option.type || 'info',
        message: option.msg
      });
    }
  } catch (err) {
    console.log(err)
  }
}

module.exports = { log }