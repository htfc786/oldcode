/**
 * 窗口类
 */

const RendererEmitter = require('../ipc/ipc-preload')
const emitter = new RendererEmitter('preloadJs')

/**
 * 打开一个modal
 */
function showResource(url, type, name) {
  // 交给主进程去做这个事
  emitter.ipcSend('showResource', url, type, name)
}



const currentWin = {
  run(method, ...args) {
    emitter.ipcSend('currentWinRun', method, ...args)
  },
  get(method, ...args) {
    return emitter.ipcInvoke('currentWinGet', method, ...args)
  }
}


module.exports = {
  showResource,
  currentWin
}
