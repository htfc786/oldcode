/**
 * 替换基础类
 * 执行add、delete、replace基础操作
 * 根据配置文件进行操作
 */
const path = require("path");
const fs = require("fs-extra");


// 加上作用域，防止重复

class RunPack {
  constructor(option) {
    this.packageName = option.packageName
    this.backPackageName = option.backPackageName
    this.rootPath = option.rootPath
    this.updatePath = option.updatePath
    this.CHANGEJSON = 'change.json'


  }

  getRealResourcePath(resourcePath, namespace) {
    return path.join(this.updatePath, this.packageName, 'resource', namespace, resourcePath)
  }

  getRealTargetPath(targetPath) {
    return path.join(this.rootPath, targetPath)
  }

  getRealBackupPath(backupPath, namespace) {
    return path.join(this.updatePath, this.backPackageName, 'resource', namespace, backupPath)
  }

  add(config) {
    const { resourcePath, targetPath, resourceType, namespace } = config;
    const realResourcePath = this.getRealResourcePath(resourcePath, namespace)
    const realTargetPath = this.getRealTargetPath(targetPath)
    // 文件存在跳转replace
    if (fs.existsSync(realTargetPath)) return this.replace(config);
    // 移动文件
    this.rename(realResourcePath, realTargetPath);
    // 生成备份配置文件

    return {
      namespace: namespace,
      resourceType: resourceType,
      replaceType: "delete",
      resourcePath: "",
      targetPath: targetPath
    };
  }

  replace(config) {
    const { resourcePath, targetPath, resourceType, namespace } = config;
    // 老文件备份到备份目录，新文件替换老文件
    const realResourcePath = this.getRealResourcePath(resourcePath, namespace)
    const realTargetPath = this.getRealTargetPath(targetPath)
    const realBackupPath = this.getRealBackupPath(targetPath, namespace)
    if (fs.existsSync(realTargetPath)) {
      this.rename(realTargetPath, realBackupPath);
      try {
        this.rename(realResourcePath, realTargetPath);
      } catch (err) {
        this.rename(realBackupPath, realTargetPath);
        throw err;
      }
      return {
        namespace: namespace,
        resourceType: resourceType,
        replaceType: "replace",
        resourcePath: targetPath,
        targetPath: targetPath
      };
    } else {
      return this.add(config);
    }
  }

  delete(config) {
    const { targetPath, resourceType, namespace } = config;
    // 执行删除操作，删除前先进行备份
    const realTargetPath = this.getRealTargetPath(targetPath)
    const realBackupPath = this.getRealBackupPath(targetPath, namespace)
    if (fs.existsSync(realTargetPath)) {
      this.rename(realTargetPath, realBackupPath);
      return {
        namespace: namespace,
        resourceType: resourceType,
        replaceType: "add",
        resourcePath: targetPath,
        targetPath: targetPath
      };
    }
  }

  recursiveCover(config) {
    this.recursiveCover.changeList = this.recursiveCover.changeList || [];
    const { resourcePath, targetPath, resourceType, namespace } = config;
    if (resourceType !== "folder")
      throw new Error("resourceType must be folder !");
    const files = fs.readdirSync(this.getRealResourcePath(resourcePath, namespace));
    if (files.length === 0) return;
    files.map(file => {
      const fileTargetPath = path.join(targetPath, file);
      const fileResourcePath = path.join(resourcePath, file);
      const stat = fs.statSync(this.getRealResourcePath(fileResourcePath, namespace));
      if (stat.isDirectory()) {
        // 是文件夹
        this.recursiveCover({
          namespace: namespace,
          resourceType: resourceType,
          replaceType: "cover",
          resourcePath: fileResourcePath,
          targetPath: fileTargetPath
        });
      } else {
        // 是文件,判断是否有老文件存在
        if (fs.existsSync(fileTargetPath)) {
          const list = this.replace({
            namespace: namespace,
            resourceType: "file",
            replaceType: "replace",
            resourcePath: fileResourcePath,
            targetPath: fileTargetPath
          });
          this.recursiveCover.changeList.push(list);
        } else {
          const list = this.add({
            namespace: namespace,
            resourceType: "file",
            replaceType: "add",
            resourcePath: fileResourcePath,
            targetPath: fileTargetPath
          });
          this.recursiveCover.changeList.push(list);
        }
      }
    });
  }

  cover(config) {
    try {
      this.recursiveCover(config);
      const list = this.recursiveCover.changeList;
      this.recursiveCover.changeList = [];
      return list;
    } catch (err) {
      // 采用内部控制
      this.recursiveCover.changeList.forEach(item => {
        if (item.replaceType == "replace") {
          this.replace(item);
        } else {
          this.delete(item);
        }
      });
      this.recursiveCover.changeList = [];
      throw err;
    }
  }

  rename(oldPath, newPath) {
    const dirname = path.dirname(newPath);
    fs.ensureDirSync(dirname);
    fs.renameSync(oldPath, newPath);
    // console.log("文件移动： " + oldPath + "---->" + newPath);
  }

  replaceFiles(config, stop) {
    const changeList = [];
    try {
      config.forEach(item => {
        if (item && item.replaceType) {

          switch (item.replaceType) {
            case "cover":
              // console.log("cover");
              changeList.push(...this.cover(item));
              break;
            case "replace":
              // console.log("replace");
              changeList.push(this.replace(item));
              break;
            case "add":
              // console.log("add");
              changeList.push(this.add(item));
              break;
            case "delete":
              // console.log("delete");
              changeList.push(this.delete(item));
              break;
          }
        }
      });
      return changeList;
    } catch (err) {
      // console.log(changeList);
      if (!stop) this.replaceFiles(changeList, true);
      const errMsg = stop ? `回滚出错，错误代码${err.stack}` : `替换出错，错误代码${err.stack}`
      throw new Error(errMsg);
    }
  }


  run() {
    let packagePath = path.join(this.updatePath, this.packageName)
    let changeJsonPath = path.join(packagePath, this.CHANGEJSON)
    let config = fs.readJSONSync(changeJsonPath)
    let changeConfig = this.replaceFiles(config)
    // 写入changeConfig
    const changeConfigPath = path.join(this.updatePath, this.backPackageName, this.CHANGEJSON)
    fs.ensureDirSync(path.dirname(changeConfigPath));
    fs.writeJSONSync(changeConfigPath, changeConfig, { spaces: 2 })
  }
}




module.exports = RunPack
