const windowManager = require("electron-window-manager");
const loginType = global.environment.userType === "teacher" ? "login-t" : "login-s";
const { sendInfo } = require('./log/index')
const { BrowserWindow, app } = require('electron')


function getServerUrl(userType) {
  // 获取serverurl
  switch (userType) {
    case "sales":
      return "/zmc-webapp/sales/login/";
    case "student":
      return "/zmc-webapp/zmlearnclient/login-s/";
    case "teacher":
    default:
      return "/zmc-webapp/zmlearnclient/login-t/";
  }
}

// const serverUrl = `${global.environment.domain}/zmc-webapp/zmlearnclient/${loginType}/`;
const serverUrl = `${global.environment.domain}${getServerUrl(global.environment.userType)}`;


function createLoginWin() {
  const win = windowManager.open(
    "Login",
    global.environment.appName,
    serverUrl,
    false,
    {
      width: 340,
      height: 420,
      resizable: false,
      frame: false,
      center: true,
      transparent: false,
      backgroundColor: "#999999",
      webPreferences: {
        webSecurity: false,
        nodeIntegration: true
      }
    }
  );
  win.object.center();
  win.object.webContents.on("did-finish-load", function () {
    global.performance.mark("main-login-did-finish-load");
    try {
      const list = global.performance.end();
      if (list.length) {
        sendInfo("performance-time", JSON.stringify(list, null, 2));
      }
    } catch (err) { }
  });
}

function createLoginWinWithLoginOut() {
  const win = windowManager.open(
    "Login",
    global.environment.appName,
    serverUrl,
    false,
    {
      width: 340,
      height: 420,
      resizable: false,
      frame: false,
      center: true,
      transparent: false,
      backgroundColor: "#999999",
      webPreferences: {
        webSecurity: false,
        nodeIntegration: true
      }
    },
    false,
    {
      'remember-login-password': 0
    }
  );
  win.object.center();
}

function quitIfNoWindow() {
  setTimeout(() => {
    const wins = BrowserWindow.getAllWindows();
    if (wins.length === 0) app.quit();
  }, 500);
}

module.exports = {
  createLoginWin,
  createLoginWinWithLoginOut,
  quitIfNoWindow
}