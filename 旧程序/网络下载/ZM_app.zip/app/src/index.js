/**
 * 项目主入口
 */

// 初始化性能监控
require("./main/performance");
global.performance.mark("index-start");
const { app } = require('electron');

// 全局环境变量
require('./main/env')
require('./main/app-events')

const { sendInfo, logDebug } = require('./main/log/index')
logDebug('日志模块启动成功，全局环境变量为', global.environment)
const { setMutex, setSingleInstance, setBaseConfig, getRegeditInfo } = require('./main/single-function')
const { catchGlobalError, reportCrash } = require('./main/error-report')
const main = require("./main/main.js");
const { finishUpdate } = require("./main/update/update");
// 初始埋点
sendInfo("inin-finished", "环境初始化成功");

// 设置程序锁
setMutex()

// 开启调试
catchGlobalError();

// 单例模式
if (!setSingleInstance()) return;

// 上报崩溃
reportCrash();

// 基础设置
setBaseConfig();

// 获取其他版本客户端
getRegeditInfo()

finishUpdate()
  .then(finished => {
    if (!finished) throw new Error("无需完成更新！")
    app.relaunch();
    app.exit(0);
  })
  .catch(() => {
    app.whenReady()
      .then(() => {
        main.start();
      })
  })