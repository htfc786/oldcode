const fs = require('fs-extra')
const path = require('path')
const crypto = require('crypto')
const { app, webContents } = require('electron')
const userDataPath = app.getPath('userData')
const rootPath = path.join(userDataPath, 'zm-download')
const RequestQueue = require('./request-queue')
const { sendInfo, sendError } = require('../log/index')

class Download {

  /**
   * 
   * @param {option} option {namespace, maxRequest, saveFileInterval, progressInterval, callback }
   */
  constructor(option) {
    this.downloadQueue = []
    this.rootPath = rootPath
    this.callback = option.callback
    this.namespace = option.namespace
    this.namespacePath = path.join(this.rootPath, this.namespace)
    this.downloadQueuePath = path.join(this.namespacePath, 'downloadQueue.json')
    this.init(option)
  }

  /**
   * 项目初始化操作
   */
  init(option) {
    // 创建rootPath和namespace目录
    fs.ensureDirSync(this.namespacePath);
    this.downloadQueue = this.getLocalConfig()
    this.localClock = false
    this.memoryClock = false
    this.deleteNonExistConfig()
    // 初始化的时候所有状态都是暂停的
    this.abortDownloadingConfig()
    this.requestQueue = new RequestQueue({
      max: option.maxRequest || 5,
      rootPath: this.namespacePath
    })

    // 10分钟删除一次本地文件已经不存在的配置文件
    setInterval(this.deleteNonExistConfig.bind(this), 10 * 60 * 1000)
    // 5秒钟写一次本地文件（设定一个写状态值，写了设为false，有改变设为true）
    setInterval(this.setLocalConfigAsync.bind(this), option.saveFileInterval || 5000)
    // 1秒钟上报渲染进程一次下载进度（同上使用状态值）
    if (this.callback) {
      setInterval(this.runCallback.bind(this), option.progressInterval || 1000);
    }
  }

  deleteNonExistConfig() {
    this.downloadQueue = this.downloadQueue.filter(item => {
      try {
        return fs.existsSync(item.filePath)
      } catch (err) {
        return false
      }
    })
  }

  abortDownloadingConfig() {
    this.downloadQueue.forEach(item => {
      if (item.type === 'downloading') item.type = 'abort'
    })
  }

  runCallback() {
    if (this.memoryClock) {
      this.memoryClock = false
      this.callback(this.downloadQueue)
    }
  }

  getLocalConfig() {
    try {
      return fs.readJsonSync(this.downloadQueuePath)
    } catch (err) {
      return []
    }
  }

  setLocalConfig() {
    fs.ensureDir(this.namespacePath)
    fs.writeJsonSync(this.downloadQueuePath, this.downloadQueue, { spaces: 2 })
  }

  async setLocalConfigAsync() {
    if (this.localClock) {
      this.localClock = false
      return fs.writeJson(this.downloadQueuePath, this.downloadQueue, { spaces: 2 })
    }
  }

  setConfig(config) {
    this.localClock = true
    this.memoryClock = true
    config.changeTime = new Date().getTime()
    let hasConfig = false
    this.downloadQueue.forEach((res, index) => {
      if (res.fileName === config.fileName && res.relativePath === config.relativePath) {
        this.downloadQueue[index] = Object.assign({}, res, config)
        hasConfig = true
      }
    })
    if (!hasConfig) {
      this.downloadQueue.push(config)
    }

    if (config.callbackChannel && config.callbackChannel !== '') {
      let webcontentsList = webContents.getAllWebContents()
      webcontentsList.forEach(item => {
        item.send(config.callbackChannel, config)
      })
    }
  }


  getConfig(option) {
    if (typeof option === 'string') {
      option = {
        fileName: option,
        relativePath: ''
      }
    }
    return this.downloadQueue.filter(item => item.fileName === option.fileName && item.relativePath === option.relativePath)[0]
  }


  async __download(userConfig) {
    console.log('开始下载')
    if (!userConfig || !userConfig.url) {
      throw new Error('missing parameter: url')
    }

    //（检测过期删除）
    this.deleteExpireFile()

    const downloadingConfig = this.fixConfig(userConfig)
    const memoryConfig = this.getConfig(downloadingConfig)

    if (!memoryConfig) {
      downloadingConfig.downloadingPromise = this.rangeDownload(downloadingConfig)
      this.setConfig(downloadingConfig)
      this.setLocalConfig()
      return downloadingConfig.downloadingPromise
    } else {
      switch (memoryConfig.type) {
        case 'downloading':
          console.log('go downloading')
          return memoryConfig.downloadingPromise
        case 'done':
        case 'abort':
          console.log('go done or abort')
          downloadingConfig.downloadingPromise = this.rangeDownload(downloadingConfig, memoryConfig)
          this.setConfig(downloadingConfig)
          this.setLocalConfig()
          return downloadingConfig.downloadingPromise
      }
    }
  }


  async download(userConfig) {
    sendInfo('downloadStart', `开始下载: ${userConfig.fileName}, url: ${userConfig.url}`)
    return this.__download(userConfig).then(res => {
      sendInfo('downloadSuccess', `下载成功: ${userConfig.fileName}, url: ${userConfig.url}`)
      return res
    }).catch(err => {
      sendError('downloadError', `下载失败: ${userConfig.fileName}, url: ${userConfig.url}`, err)
      throw err
    })
  }

  fixConfig(userConfig) {
    // 整合userConfig
    userConfig.fileName = userConfig.fileName || userConfig.url.split('/').pop()
    const downloadingConfig = Object.assign({
      progress: 0,
      type: 'downloading',
      changeTime: new Date().getTime(),
      relativePath: ''
    }, userConfig)
    downloadingConfig.filePath = path.join(this.namespacePath, downloadingConfig.relativePath, downloadingConfig.fileName)
    if (downloadingConfig.decompress) {
      const lastFileName = downloadingConfig.fileName.slice(0, downloadingConfig.fileName.lastIndexOf('.'))
      downloadingConfig.decompressPath = path.join(this.namespacePath, downloadingConfig.relativePath, lastFileName)
    }
    return downloadingConfig
  }

  deleteExpireFile() {
    this.downloadQueue = this.downloadQueue.filter(item => {
      // 判断超时的内容，
      // console.log('item', item)
      if (!item.storageTime) return true
      let now = new Date().getTime()
      let expire = now - parseInt(item.changeTime) >= parseInt(item.storageTime)
      // console.log('expire', expire)
      if (!expire) return true
      try {
        fs.removeSync(item.filePath)
        fs.removeSync(item.decompressPath)
      } catch (err) {
        console.log(err)
      }
      return false
    })
  }


  async bulkDownload(configList) {
    return Promise.all(configList.map(item => this.download(item)))
  }

  async request(downloadingConfig, oldMemoryConfig) {
    try {
      this.setConfig(downloadingConfig)
      this.setLocalConfig()
      const result = await this.requestQueue.request(downloadingConfig, (progress) => {
        downloadingConfig.progress = progress
        this.setConfig(downloadingConfig)
      })
      const completely = await this.completely(downloadingConfig)
      if (!completely) {
        this.delete(downloadingConfig)
        throw new Error('file is no completely')
      }
      // 如果能解压就解压？？
      if (downloadingConfig.decompress) {
        if (!oldMemoryConfig || !oldMemoryConfig.decompressSuccess || !fs.existsSync(downloadingConfig.decompressPath)) {
          /* try {
            fs.removeSync(downloadingConfig.decompressPath)
          } catch (err) { } */
          this.decompress(downloadingConfig)
          // 更改解压成功状态？
          downloadingConfig.decompressSuccess = true
        }
      }

      console.log('下载完成返回资源')
      downloadingConfig.type = 'done'
      this.setConfig(downloadingConfig)
      this.setLocalConfig()
      return result
    } catch (err) {
      console.log('下载失败返回错误')
      downloadingConfig.type = 'abort'
      this.setConfig(downloadingConfig)
      this.setLocalConfig()
      throw err
    }
  }

  async rangeDownload(downloadingConfig, oldMemoryConfig) {
    try {
      const fileConfig = await this.requestQueue.requestHead(downloadingConfig.url)
      downloadingConfig = Object.assign({}, downloadingConfig, fileConfig)

      if (!oldMemoryConfig) return this.request(downloadingConfig)

      let isInvalid = this.invalid(downloadingConfig, oldMemoryConfig)
      // oldMemoryConfig资源无效
      if (!isInvalid) {
        console.log('内存资源无效')
        // 删除资源重新下载
        this.delete(oldMemoryConfig)
        return this.request(downloadingConfig)
      }
      console.log('内存资源有效')
      // oldMemoryConfig资源有效
      const size = await this.getFileSize(downloadingConfig.filePath)
      downloadingConfig.currentSize = size
      return this.request(downloadingConfig, oldMemoryConfig)
    } catch (err) {
      console.log('下载失败返回错误')
      downloadingConfig.type = 'abort'
      this.setConfig(downloadingConfig)
      throw err
    }
  }

  getfilePath(option) {
    if (typeof option === "string") {
      option = {
        fileName: option,
        relativePath: ''
      }
    }
    const config = this.getConfig(option)
    if (!config) {
      throw new Error('can not find file')
    }
    return config.filePath
  }

  invalid(downloadingConfig, memoryConfig) {
    // 内存中的数据和用户透传过来的数据比对判断是否有相同的资源
    if (downloadingConfig.hashId) {
      if (downloadingConfig.etag) {
        return downloadingConfig.hashId === memoryConfig.hashId
          && downloadingConfig.etag === memoryConfig.etag
      }
      return downloadingConfig.hashId === memoryConfig.hashId
    } else if (downloadingConfig.etag) {
      return downloadingConfig.etag === memoryConfig.etag
    } else {
      return false
    }
  }

  decompress(downloadingConfig) {
    try {
      const AdmZip = require('adm-zip');
      if (!fs.existsSync(downloadingConfig.filePath))
        throw new Error(`解压文件失败，文件不存在,${downloadingConfig.filePath}`);
      const zip = new AdmZip(downloadingConfig.filePath);
      zip.extractAllTo(downloadingConfig.decompressPath, true);
    } catch (err) {
      throw err;
    }
  }

  /**
   * 暂停下载
   */
  async abort(fileName) {
    // 内存中是最真实的数据，先查找内存
    let memoryConfig = this.getConfig(fileName)
    // 如果没有
    if (!memoryConfig) {
      throw new Error('nothing downloading!')
    }
    return this.requestQueue.abort(fileName)
  }

  async abortAll() {
    return this.requestQueue.abortAll()
  }

  // 以上暂停下载没有回调，不改变memoryconfig,已经在下载回调里改变了
  downloadAll() {
    // 循环下载所有的
    let promiseQueue = this.downloadQueue.filter(item => {
      if (item.type === 'abort') return this.download(item)
    })
    return Promise.all(promiseQueue)
  }

  delete(config) {
    console.log('remove, download')
    // 删除配置和文件
    this.downloadQueue = this.downloadQueue.filter(item => item.fileName !== config.fileName || item.relativePath !== config.relativePath)
    try {
      fs.removeSync(config.filePath)
      fs.removeSync(config.decompressPath)

    } catch (err) {
      console.log('remove file err', err)
    }
  }

  deleteFileName(fileName) {
    let config = this.downloadQueue.filter(item => item.fileName === fileName)[0]
    if (config) {
      this.delete(config)
      this.downloadQueue = this.downloadQueue.filter(item => item.fileName !== fileName)
      this.setLocalConfig()
    } else {
      throw new Error('no fileName')
    }
  }

  deleteFilePath(filePath) {
    try {
      if (fs.existsSync(filePath)) fs.removeSync(filePath)
    } catch (err) {
      console.log('remove file err', err)
    }
  }

  copy(sourcePath, targetPath) {
    return fs.copy(sourcePath, targetPath)
  }

  move(sourcePath, targetPath) {
    return fs.move(sourcePath, targetPath)
  }

  deleteAll() {
    return fs.remove(this.namespacePath).then(() => fs.ensureDirSync(this.namespacePath))
  }

  completely(config) {
    return new Promise((resolve, reject) => {
      // 没有MD5默认返回true
      if (!config.md5 && !config.contentMd5) {
        resolve(true)
        return
      }
      let filePath = path.join(this.namespacePath, config.relativePath, config.fileName)
      const md5 = config.md5 ? config.md5 : Buffer.from(config.contentMd5, 'base64').toString('hex')
      const hash = crypto.createHash("md5");
      fs.readFile(filePath, (err, data) => {
        if (err) {
          resolve(false);
          return;
        }
        try {
          hash.update(data);
          const mainSha512 = hash.digest("hex");
          resolve(md5 === mainSha512);
        } catch (err) {
          resolve(false);
        }
      });
    });
  }

  getFileSize(file) {
    return new Promise((resolve, reject) => {
      if (!fs.existsSync(file)) {
        resolve(0)
        return
      }
      fs.stat(file, function (err, stats) {
        if (err) {
          reject(err)
          return
        }
        resolve(stats.size)
      })
    })
  }

  /**
   * 是否支持断点续传
   * @param {object} config 
   */
  supportRange(config) {
    return config && config.etag && config.acceptRanges === 'bytes'
  }
}

class Downloader {
  constructor(option) {
    Downloader.instance = Downloader.instance || {}
    if (!Downloader.instance[option.namespace]) {
      Downloader.instance[option.namespace] = new Download(option)
    }
    return Downloader.instance[option.namespace]
  }
}

module.exports = Downloader
