/**
 * node桥接c++文件
 */
const fs = require('fs')
const path = require('path')
const { app } = require('electron')
const { getDeviceId, storage } = require('node-environment')
const windowManager = require("electron-window-manager");
const { sendError, sendInfo } = require('./log/index')
const update = require("./update/update");
const { createLoginWinWithLoginOut } = require("./window");
const exePath = path.dirname(app.getPath('exe'))
const nodePath = path.join(exePath, 'zmlearn')

const loginType = global.environment.userType === "teacher" ? "login-t" : "login-s";
const serverUrl = `${global.environment.domain}/zmc-webapp/zmlearnclient/${loginType}/`;

let zmlearnPlugin = null;
let ws_server = null;

function windowManagerInit() {
  let oldTime = new Date() - 2001;
  windowManager.init({
    onLoadFailure: function (
      window,
      event,
      errorCode,
      errorDescription,
      validatedURL,
      isMainFrame
    ) {
      sendInfo("onLoadFailure", JSON.stringify({
        errorCode: errorCode,
        errorDescription: errorDescription,
        validatedURL: validatedURL,
        isMainFrame: isMainFrame
      }, null, 2));

      // 条件 isMainFrame为true，errorCode不等于-3，页面固定为登录页面，检测5秒内依然为灰屏状态，两秒内不重复检测
      if (isMainFrame === true && errorCode !== -3 && validatedURL === serverUrl) {
        let nowTime = new Date();
        if (nowTime - oldTime > 2000) {
          sendInfo("intervalCheck", "开始检测是否灰屏！");
          oldTime = nowTime;
          window.object.webContents
            .executeJavaScript(
              `
              (function () {
                function appIsExist (perTime) {
                  return new Promise((resolve, reject) => {
                    setTimeout(function () {
                      try {
                        console.log('find dom')
                        if (document.body.childNodes.length) {
                          resolve(true) // 存在
                        } else {
                          resolve(false) // 不存在
                        }
                      } catch (err) {
                        reject(err)
                      }
                    }, perTime)
                  }).catch(err => false)
                }

                async function intervalCheck (totalTime, perTime) {
                  let sumTime = 0
                  let appExist = false
                  while (!appExist && sumTime <= totalTime) {
                    appExist = await appIsExist(perTime)
                    sumTime += perTime
                  }
                  return appExist
                }
                return intervalCheck(5000, 500)
              })()
            `,
              true
            )
            .then(result => {
              // 判断默认加载失败页面是否存在
              const urls = path.join(global.environment.rootPath, "src/renderer/windows/error/loadfail.html");
              if (
                fs.existsSync(urls) &&
                window &&
                window.object &&
                window.object.webContents &&
                !result
              ) {
                const reloadurl = encodeURIComponent(validatedURL);
                window.object.webContents.loadURL(
                  "file://" + urls + `?reloadurl=${reloadurl}&errorCode=${errorCode}&errorDescription=${errorDescription}`
                );
              }
            });
        }
      }
    }
  });
  windowManager.bridge.on("createLoginWin", data => {
    windowManager.sharedData.set("is_login_out", true);
    // 调用另外一种方案来区分登陆
    createLoginWinWithLoginOut();
  });
  //通用方法
  windowManager.bridge.on("nativemethodexec", data => {
    let { funcname, params, funcName, cbStr } = data;
    if (funcname) {
      const func = zmlearnPlugin[funcname];
      if (func) func(...params);
    } else if (funcName) {
      const func = zmlearnPlugin[funcName];
      const p_arr = [];
      for (var key in params) {
        p_arr.push(params[key]);
      }
      if (cbStr) p_arr.push(cbStr);

      if (func) func(...p_arr);
    }
  });

  //插件初始化
  windowManager.bridge.on("InitPlugin", async msg => {
    try {
      const deviceId = await getDeviceId().catch(err => '');
      msg.deviceId = deviceId;
      msg.role = global.environment.userType;
      // 检查更新
      checkUpdateInterval(msg)

      if (!zmlearnPlugin) {
        zmlearnPlugin = require(nodePath);
        zmlearnPlugin.InitModule(JSON.stringify(msg));
        zmlearnPlugin.Interface(data => {
          try {
            console.log("Interface", data);
            const json = JSON.parse(data);
            if (
              json.SendType === "ws" &&
              ws_server &&
              ws_server.readyState === 1
            ) {
              ws_server.send(data);
            } else {
              windowManager.bridge.emit("nativeCallBack", JSON.parse(data));
            }
          } catch (error) {
            sendError(
              "PluginInterfaceFailure",
              "Interface回调函数报错！",
              error
            );
          }
        });
      } else {
        zmlearnPlugin.updateModuleInfo(JSON.stringify(msg));
      }
      storage.setItem({
        'userId': msg.userId
      })
    } catch (error) {
      sendError("InitPluginFailure", "InitPlugin捕获到的错误", error);
    }
  });
}


function checkUpdateInterval(msg) {
  if (checkUpdateInterval.interval) return
  function updates() {
    update.checkUpdate({
      clientTypeCode: "PC_CLIENT_WINDOWS",
      userId: msg.userId,
      userRole: global.environment.userType,
      version: global.environment.version,
      resourceVersion: global.environment.resourceVersion,
      access_token: msg.token
    })
      .catch(err => {
        let token
        if (msg) {
          token = msg.token
        } else {
          token = 'no-token'
        }
        sendError("checkUpdateError", `检查更新失败，token：${token}`, err)
      })
  }
  updates()
  checkUpdateInterval.interval = setInterval(updates, 1000 * 3600 * 2)
}

module.exports = {
  windowManagerInit
}