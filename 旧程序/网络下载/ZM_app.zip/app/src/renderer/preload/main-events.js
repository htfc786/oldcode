/**
 * electron api 调用
 */

const RendererEmitter = require('../ipc/ipc-preload')
const mainEvents = new RendererEmitter('insteadOfRemoteCall')
module.exports = mainEvents