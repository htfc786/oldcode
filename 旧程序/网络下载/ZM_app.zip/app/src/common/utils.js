function getDate() {
  const date = new Date()
  const year = date.getFullYear()
  let month = date.getMonth()
  let day = date.getDate()
  month++
  month = month < 10 ? `0${month}` : month
  day = day < 10 ? `0${day}` : day
  return `${year}-${month}-${day}`
}

/**
 * 异步并发执行函数
 * @param {number} poolLimit 
 * @param {array} array 
 * @param {function} iteratorFn 
 * @param {function} catchError 
 * @returns 
 */
async function asyncPool(poolLimit, array, iteratorFn, catchError) {
  const resultPromiseList = []
  const poolPromiseList = []
  for (let item of array) {
    const p = Promise.resolve().then(() => iteratorFn(item, array)).catch(err => catchError(err))
    resultPromiseList.push(p)
    const s = p.then(() => poolPromiseList.splice(poolPromiseList.indexOf(s), 1))
    poolPromiseList.push(s)
    if (poolPromiseList.length >= poolLimit) {
      await Promise.race(poolPromiseList)
    }
  }
  return Promise.all(resultPromiseList)
}

/**
 * 异步顺序执行函数
 * @param {array} array 
 * @param {function} iteratorFn 
 * @param {function} catchError 
 */
async function asyncStack(array, iteratorFn, catchError) {
  let list = []
  for (let item of array) {

    let res = await Promise.resolve(iteratorFn(item)).catch(err => {
      if (catchError) {
        return catchError(err)
      } else {
        throw err
      }
    })
    list.push(res)
  }
  return list
}


module.exports = {
  getDate,
  asyncPool,
  asyncStack
}
