/**
 * gpu禁用策略
 */

const { storage, getDeviceId } = require('node-environment')
const gpuCrashMaxLen = 10
const fetch = require('node-fetch')
const { sendError, sendInfo } = require('./log/index')
const mainEvents = require('./ipc/mainEvents')
let hasUpdate = false


/**
 * 获取本地gpu策略
 */
function getLocalGpuStrategy() {
  return storage.getItem('gpu-strategy', {
    state: true,
    interval: 10,
    crashTime: 2
  })
}

/**
 * 设置本地gpu策略
 */
function setLocalGpuStrategy(config) {
  const gpuStrategy = getLocalGpuStrategy()
  storage.setItem({
    'gpu-strategy': Object.assign(gpuStrategy, config)
  })
}

/**
 * 记录gpu崩溃状态
 */
function setGpuCrashState() {
  const gpuCrashList = getGpuCrashState()
  if (gpuCrashList.length < gpuCrashMaxLen) {
    gpuCrashList.push(new Date().getTime())
  } else {
    gpuCrashList.shift()
    gpuCrashList.push(new Date().getTime())
  }
  storage.setItem({
    gpuCrashList: gpuCrashList
  })
}


/**
 * 获取gpu崩溃状态
 */
function getGpuCrashState() {
  return storage.getItem('gpuCrashList', [])
}

/**
 * 上报gpu崩溃信息
 */
async function updateGpuCrashInfo() {
  const checkUpdateApi = `${global.environment.domain}/gateway/zmc-heimdall/gpu/crashUpdate`
  const deviceId = await getDeviceId()
  const graphics = await getGraphicsInfo()
  const option = {
    deviceId: deviceId,
    gpuInfo: graphics,
    osInfo: getWindowsType(),
    versionInfo: global.environment.version
  }
  return fetch(checkUpdateApi, {
    method: 'POST',
    timeout: 3000,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(option)
  })
    .then(res => {
      if (res && res.status === 200) {
        return res.json()
      } else {
        throw new Error(`http请求错误状态码：${res.status},错误信息：${res.statusText}`)
      }
    })
    .then(res => {
      if (res.code !== '0') {
        throw new Error(`服务端错误：${res.code},错误信息：${res.message}`)
      }
      hasUpdate = true
      return res.data
    })
}

/**
 * 判断是否需要上报崩溃
 * 条件：1.当前用户已经开启gpu加速，2.超出最大崩溃阈值，3. 本次打开没有触发过弹窗警告
 */
function ifUpdateGpuCrash() {
  const gpuStrategy = getLocalGpuStrategy()
  const gpuCrashList = getGpuCrashState()
  const matchList = gpuCrashList.filter(timeStamp => timeStamp >= new Date().getTime() - gpuStrategy.interval * 60 * 1000)
  return global.environment.gpuStrategyState && matchList.length >= gpuStrategy.crashTime && !hasUpdate
}

/**
 * 同步线上禁用gpu数据
 */
async function getOnLineGpuStrategy() {
  const checkUpdateApi = `${global.environment.domain}/gateway/zmc-heimdall/gpu/getSetting`
  const deviceId = await getDeviceId()
  const graphics = await getGraphicsInfo()
  const option = {
    deviceId: deviceId,
    gpuInfo: graphics,
    osInfo: getWindowsType(),
    versionInfo: global.environment.version
  }
  return fetch(checkUpdateApi, {
    method: 'POST',
    timeout: 3000,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(option)
  })
    .then(res => {
      if (res && res.status === 200) {
        return res.json()
      } else {
        throw new Error(`http请求错误状态码：${res.status},错误信息：${res.statusText}`)
      }
    })
    .then(res => {
      if (res.code !== '0') {
        throw new Error(`服务端错误：${res.code},错误信息：${res.message}`)
      }
      return res.data
    })
}

/**
 * 更改本地gpu缓存策略
 */
async function changeLocalGpuStrategy() {
  // 如果本地是false就不请求
  try {
    const gpuStrategy = getLocalGpuStrategy()
    if (!gpuStrategy.state) return;
    const onLineGpuStrategy = await getOnLineGpuStrategy()
    const data = {
      state: onLineGpuStrategy.open,
      interval: onLineGpuStrategy.interval,
      crashTime: onLineGpuStrategy.crashTime
    }
    setLocalGpuStrategy(data)
  } catch (err) {
    sendError('changeLocalGpuStrategyError', '同步gpu数据失败', err)
  }
}


function getWindowsType() {
  const os = require('os')
  const release = os.release()
  const releaseMap = new Map([
    ['10.1', 'Win10'],
    ['10.0', 'Win10'],
    ['6.3', 'Win8.1'],
    ['6.2', 'Win8'],
    ['6.1', 'Win7']
  ])
  const releaseArray = release.split('.')
  releaseArray.length = 2
  return releaseMap.get(releaseArray.join('.'))
}

async function getGraphicsInfo() {
  // 获取gpu信息
  const si = require('systeminformation');
  let graphicsInfo = storage.getItem('graphicsInfo')
  if (!graphicsInfo) {
    let graphics = await si.graphics()
    graphicsInfo = graphics.controllers[0].model
    storage.setItem({
      graphicsInfo: graphicsInfo
    })
  }
  return graphicsInfo
}

function handleGpuCrash() {
  sendError("gpu-process-crashed", "gpu进程崩溃！");
  const { gpuCrashDialog } = require('./dialog')
  // 记录崩溃信息
  setGpuCrashState()
  // 广播给渲染进程gpu崩溃
  tellRendererGpuCrash()
  // 判断是否超出阈值
  const ifMax = ifUpdateGpuCrash()
  // 超出阈值弹窗提示用户
  if (ifMax) {
    gpuCrashDialog()
      .then(res => {
        // 发送gpu崩溃报告
        if (res.response === 0) {
          setLocalGpuStrategy({
            state: false
          })
          updateGpuCrashInfo()
          // 发送埋点用户禁用gpu
          sendInfo("disable-gpu", "用户主动禁用gpu");
        }
      })
  }
}

function tellRendererGpuCrash() {
  mainEvents.emitRenderer('gpu-process-crashed')
}

module.exports = {
  setLocalGpuStrategy,
  getLocalGpuStrategy,
  setGpuCrashState,
  getGpuCrashState,
  updateGpuCrashInfo,
  ifUpdateGpuCrash,
  getOnLineGpuStrategy,
  changeLocalGpuStrategy,
  handleGpuCrash
}
