/**
 * 性能监控
 * 包含主进程和渲染进程
 */
const { app, BrowserWindow } = require('electron')
const { log } = require('./log/index')
const { storage, getDeviceId } = require('node-environment')
const { getGray } = require('./best')
let timer = null

function getMonitorData() {
  const os = require('os')
  const data = app.getAppMetrics()
  const freemem = os.freemem()
  return {
    appMetrics: data,
    freemem: freemem
  }
}

async function getMonitorStatus() {
  try {
    const deviceId = await getDeviceId()
    const { grayCode } = require('../common/constants')
    const monitorStatus = await getGray({
      grayCode: grayCode.GRAY_1v1_MONITOR,
      map: {
        deviceId: deviceId,
        version: global.environment.version,
        resourceVersion: global.environment.resourceVersion,
      }
    })
    storage.setItem({
      monitorStatus: monitorStatus
    })
    return monitorStatus
  } catch (err) {
    return storage.getItem('monitorStatus', false)
  }
}

function getCpus(previousCpus = {}) {
  previousCpus.idle = previousCpus.idle || 0
  previousCpus.total = previousCpus.total || 0
  const os = require('os')
  const cpus = os.cpus()
  let user = 0, nice = 0, sys = 0, idle = 0, irq = 0, total = 0;
  for (let cpu in cpus) {
    const times = cpus[cpu].times;
    user += times.user;
    nice += times.nice;
    sys += times.sys;
    idle += times.idle;
    irq += times.irq;
  }
  total += user + nice + sys + idle + irq;
  const currentCpus = { user, sys, idle, total }
  idle = currentCpus.idle - previousCpus.idle;
  total = currentCpus.total - previousCpus.total;
  let usage = 1 - idle / total;
  usage = (usage * 100).toFixed(2) + "%";
  currentCpus.usage = usage
  return currentCpus
}

async function startReportCpuAndGpuInfo() {
  if (timer) return
  let previousCpus
  // 获取命中策略
  timer = setInterval(function () {
    previousCpus = getCpus(previousCpus)
    const data = getMonitorData()
    data.cpuUsage = previousCpus.usage
    log({
      logName: 'performance',
      model: 'main',
      msg: JSON.stringify(data),
      code: 'app-usages'
    })
  }, 2000)
}

function stopReportCpuAndGpuInfo() {
  if (timer) {
    clearInterval(timer)
    timer = null
  }
}


async function startMonitor() {
  const monitorStatus = await getMonitorStatus()
  const winList = BrowserWindow.getAllWindows()
  // 关闭本地监控配置
  if (winList) {
    winList.forEach(item => {
      item.webContents.send('renderer-preload', monitorStatus)
    })
  }
  monitorStatus ? startReportCpuAndGpuInfo() : stopReportCpuAndGpuInfo()
}

function getCrashPcInfo() {
  const os = require('os')
  const totalmem = os.totalmem()
  const freemem = os.freemem()
  const cpus = os.cpus()
  const cpuName = cpus[0].model
  const cpuLen = cpus.length
  const data = app.getAppMetrics()
  const clientDuration = process.uptime()
  const clientTotalmem = data.reduce((accumulator, currentValue) => {
    return accumulator + currentValue['memory']['workingSetSize']
  }, 0)
  const info = {
    systemInfo: {
      cpuName: cpuName,
      cpuLen: cpuLen,
      freemem: (freemem / 1073741824).toFixed(2) + 'GB',
      totalmem: Math.ceil(totalmem / 1073741824) + 'GB'
    },
    clientInfo: {
      processNum: data.length,
      totalmem: (clientTotalmem / 1024).toFixed(2) + 'MB'
    },
    clientDuration: clientDuration.toFixed(2) + 's',
    extra: {
      appMetrics: app.getAppMetrics()
    }
  }
  return info
}

module.exports = {
  startMonitor,
  getCpus,
  getCrashPcInfo
}