/**
 * oss上传
 */

const OSS = require('ali-oss')
const fetch = require('node-fetch')

function getAliossAccess(option) {
  const accessUrl = `${global.environment.domain}/gateway/zmc-monitor/api/oss/getOssAccessKey`
  return fetch(accessUrl, {
    method: 'POST',
    timeout: 5000,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(option)
  })
    .then(res => {
      if (res && res.status === 200) {
        return res.json()
      } else {
        throw new Error(`http请求错误状态码：${res.status},错误信息：${res.statusText}`)
      }
    })
    .then(res => {
      console.log(res)
      if (res.code !== '0') {
        throw new Error(`服务端错误：${res.code},错误信息：${res.message}`)
      }
      return res.data
    })
}

async function uploadOSS(filePath, uploadPath) {
  const { accessKeyId, accessKeySecret, securityToken, bucket, folderPath } = await getAliossAccess({
    "extension": "log",
    "funcPoint": "PERFORMANCE_LOG"
  })
  const objectName = `${folderPath}/${uploadPath}`
  const client = new OSS({
    accessKeyId,
    accessKeySecret,
    bucket,
    stsToken: securityToken,
  });
  return client.put(objectName, filePath)
    .then(data => {
      if (!data.res || data.res.status !== 200) {
        throw new Error(`http请求错误状态码：${data.status}`)
      }
      return data.url
    })
}

module.exports = {
  getAliossAccess,
  uploadOSS
}