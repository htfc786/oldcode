const { ipcRenderer } = require('electron')
const EventEmitter = require('events');

/**
 * 封装renderer ipc
 */

class RendererEmitter extends EventEmitter {
  constructor(name) {
    super()
    name = name || 'default'
    this.emitterName = name
    this.IPCRENDERER_SEND = `electron:renderer:${name}:send`
    this.IPCRENDERER_EMIT = `electron:renderer:${name}:emit`
    this.IPCRENDERER_ON = `electron:renderer:${name}:on`
    this.INVOKE = `electron:${name}:invoke`
    this.ON = `electron:${name}:on`
    this.init()
  }

  init() {
    ipcRenderer.on(this.IPCRENDERER_ON, (event, name, ...args) => {
      this.emitCurrentRenderer(name, ...args)
    })
  }

  emit(name, ...args) {
    this.emitMain(name, ...args)
    this.emitRenderer(name, ...args)
  }

  emitMain(name, ...args) {
    ipcRenderer.send(this.IPCRENDERER_EMIT, name, ...args)
  }

  emitRenderer(name, ...args) {
    this.emitCurrentRenderer(name, ...args)
    this.emitOtherRenderer(name, ...args)
  }

  emitCurrentRenderer(name, ...args) {
    super.emit(name, ...args)
  }

  async emitOtherRenderer(name, ...args) {
    let winIdList = await ipcRenderer.invoke('getAllOtherWebContentsID')
    if (winIdList.length) winIdList.forEach(id => this.emitToWebContents(id, name, ...args))
  }

  emitToWebContents(webContentsId, name, ...args) {
    ipcRenderer.sendTo(webContentsId, name, ...args)
  }

  on(name, fun) {
    super.on(name, fun)
  }

  ipcSend(channel, ...args) {
    channel = `${this.ON}:${channel}`
    return ipcRenderer.send(channel, ...args)
  }

  ipcInvoke(channel, ...args) {
    channel = `${this.INVOKE}:${channel}`
    return ipcRenderer.invoke(channel, ...args)
  }
}


module.exports = RendererEmitter