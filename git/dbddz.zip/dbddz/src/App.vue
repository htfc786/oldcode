<template>
  <Game></Game>
</template>

<script setup lang="ts">
import Game from './components/Game.vue';
</script>

<style scoped>
</style>
