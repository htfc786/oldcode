/**
 * main执行主函数
 */

const { sendError, sendInfo } = require('./log/index')
const { clearLogStrategy } = require('./log/upload-log')
const { localFontSize } = require('./single-function')
const { changeLocalGpuStrategy } = require('./gpu-strategy')
const { createLoginWin } = require('./window')
const { windowManagerInit } = require('./node-bridge')
const { createWs } = require('./websocket')
const { startMonitor } = require('./monitor')
const { run, baseComputerInfo } = require('./compatibility-mode')
const { createUploadShortcut, createDevtoolsShortcut } = require('./shortcut')
const { checkEXEUpdate } = require('./exe-update/index')
require('./ipc/ipc')
require('./global')


exports.start = function () {
  try {
    // 埋点
    sendInfo("appStart", "用户从main中启动程序");
    // 音视频初始化监听
    windowManagerInit();
    // 创建窗口
    createLoginWin();
    // 加载本地字体
    localFontSize();
    // 开启debug
    createDevtoolsShortcut();
    // 创建websocket
    createWs();
    // gpu策略
    changeLocalGpuStrategy()
    // 上报gpu和cpu信息
    setTimeout(function () {
      baseComputerInfo()
    }, 15000)
    setTimeout(function () {
      run()
    }, 5000)

    startMonitor()
    // 创建快捷键
    createUploadShortcut()

    setTimeout(function () {
      checkEXEUpdate().catch(err => {
        sendError("checkEXEUpdateError", "检查强制更新出错！", err);
      })
    }, 20000)

    setTimeout(function () {
      clearLogStrategy().then(res => {
        console.log('clearLogStrategy success')
      }).catch(err => {
        console.log('clearLogStrategy error', err)
      })
    }, 3000)

  } catch (err) {
    sendError("appReadyThenError", "app启动时报错！", err);
  }
};
