let max = false
let downloadUrl
let fileName

function minwin() {
  window.electronBridge.currentWin.run('minimize')
}

async function maxwin() {
  console.log(max)
  if (max) {
    window.electronBridge.currentWin.run('unmaximize')
    max = false
  } else {
    window.electronBridge.currentWin.run('maximize')
    max = true
  }
}

function closewin() {
  window.electronBridge.currentWin.run('close')
}

const emitter = new window.electronBridge.RendererEmitter('toast')

emitter.on('location-resources', function (url, type, name) {
  // 我知道很乱，为了赶时间后面再优化吧
  url = decodeURI(url)
  if (downloadUrl === url) return
  downloadUrl = url
  const embed = document.getElementById('embedid')
  const titleDom = document.getElementById('toast-title')
  let titleName = name ? name : url.split('/').pop()
  titleName = titleName.split('.').pop() !== type ? `${titleName}.${type}` : titleName
  titleDom.textContent = titleName
  fileName = titleName
  embed.innerHTML = ''
  let ele
  switch (type) {
    case 'pdf':
      ele = document.createElement('object')
      ele.data = `../pdf/web/viewer.html?file=${url}`
      ele.style.width = "100%"
      ele.style.height = "100%"
      embed.appendChild(ele)
      break;
    case 'jpg':
    case 'jpeg':
    case 'png':
    case 'gif':
      let outdiv = document.createElement('div')
      outdiv.className = 'outdivin'
      ele = document.createElement('img')
      ele.src = url
      outdiv.appendChild(ele)
      embed.appendChild(outdiv)
      ele.className = 'zoomins'
      ele.onload = function (e) {
        if (isMax(ele)) ele.className = "zoomin"
      }
      ele.onclick = function (e) {
        const ele = e.target
        if (!isMax(ele) && ele.className !== 'zoomout') {
          ele.className = 'zoomins'
        } else {
          if (ele.className === 'zoomin') {
            const imageX = parseInt((e.offsetX * ele.naturalWidth) / ele.width)
            const imageY = parseInt((e.offsetY * ele.naturalHeight) / ele.height)
            const scollToX = parseInt(imageX - embed.offsetWidth / 2)
            const scollToY = parseInt(imageY - embed.offsetHeight / 2)
            ele.className = 'zoomout'
            outdiv.className = 'outdivout'
            embed.scrollTo(scollToX, scollToY)
            console.log(imageX, imageY)
            console.log(scollToX, scollToY)
          } else {
            ele.className = 'zoomin'
            outdiv.className = 'outdivin'
          }
        }
        console.log(ele.className)
      }
      /* ele = document.createElement('iframe')
      ele.src = url
      ele.style.width = "100%"
      ele.style.height = "100%"
      embed.appendChild(ele) */
      break;
    case 'mp4':
      /* ele = document.createElement('embed')
      ele.src = url
      ele.style.width = "100%"
      ele.style.height = "100%"
      ele.autostart = false
      embed.appendChild(ele) */
      ele = document.createElement('video')
      ele.setAttribute('width', '100%')
      ele.setAttribute('height', '100%')
      ele.setAttribute('controls', 'controls')
      ele.style.outline = 'none'
      const source = document.createElement('source')
      source.src = url
      ele.appendChild(source)
      embed.appendChild(ele)
      break;
    default:
      let imageDiv = document.createElement('div')
      imageDiv.className = 'outdivin'
      ele = document.createElement('a')
      ele.style.color = "#fff";
      ele.style.textDecoration = "none"
      ele.href = url
      ele.innerText = "该类型文件暂时不支持预览，请点击此处下载！"
      embed.appendChild(imageDiv)
      imageDiv.appendChild(ele)
  }
})


function download() {
  // 打开对话框选取下载路径
  window.electronBridge.download(downloadUrl, fileName)
    .then(res => {
      console.log(res)
    }).catch(err => {
      console.log(err)
    })
}

function isMax(ele) {
  return ele.width < ele.naturalWidth || ele.height < ele.naturalHeight
}