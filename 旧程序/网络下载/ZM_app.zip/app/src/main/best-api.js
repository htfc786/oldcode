const { getGray, getPlan } = require('./best')
const { getDeviceId, storage } = require('node-environment')

async function getSaveRendererLog() {
  try {
    const deviceId = await getDeviceId()
    const { grayCode } = require('../common/constants')
    const saveLogStatus = await getGray({
      grayCode: grayCode.GRAY_1v1_WRITE_RENDERER_LOG,
      map: {
        deviceId: deviceId,
        version: global.environment.version,
        resourceVersion: global.environment.resourceVersion,
      }
    })
    storage.setItem({
      saveLogStatus: saveLogStatus
    })
    return saveLogStatus
  } catch (err) {
    return storage.getItem('saveLogStatus', false)
  }
}


module.exports = {
  getSaveRendererLog
}