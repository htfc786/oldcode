/**
 * 性能检测工具
 * 低版本node不支持perf_hooks
 * 功能：记录启动时间点，根据js页面和手动的打点， 记录单个时间点类似于time和timeEnd
 */

const { PerformanceObserver, performance } = require("perf_hooks");

let observer = null;
let observerList = [];

function performanceStart() {
  observer = new PerformanceObserver(list => {
    observerList.push(...list.getEntries());
  });
  observer.observe({ entryTypes: ["mark", "measure"] });
}

function end() {
  if (observer) {
    observer.disconnect();
    performance.clearMarks();
    observer = null;
    // observerList = [];
    return observerList
  } else {
    return []
  }
}

function mark(str) {
  performance.mark(str);
}

// 初始化
performanceStart()
global.performance = {
  mark,
  end
}
