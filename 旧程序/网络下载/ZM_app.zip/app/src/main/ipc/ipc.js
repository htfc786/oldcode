const { ipcMain, webContents } = require("electron");
const update = require("../update/update");
const { storage, ipc, getDeviceId } = require('node-environment')
const { log } = require('../log/index')
const Downloader = require('../downloader/downloader')
const downloadModules = {}
const { getSaveRendererLog } = require('../best-api')
const { sendInfo, sendError } = require('../log/index')

// 自动升级
ipcMain.on("autoUpdates", function (event, data) {
  update
    .checkForUpdates(data)
    .then(state => {
      sendInfo(state.type, state.msg);
    })
    .catch(state => {
      sendError(state.type, state.msg, state.err);
    });
});

// 检查升级
ipcMain.on("checkUpdateState", function (event, data) {
  const state = update.checkUpdateState();
  event.sender.send("checkUpdateState-reply", state);
});

// 返回监控状态
ipcMain.handle('check-if-open-monitor', function (args) {
  return storage.getItem('monitorStatus', true)
})

ipcMain.on('initDownloadModules', function (events, args) {
  try {
    if (!downloadModules[args.namespace]) {
      downloadModules[args.namespace] = new Downloader({
        namespace: args.namespace,
        callback: function (progress) {
          const webContentsList = webContents.getAllWebContents()
          webContentsList.forEach(webContent => webContent.send("downloadProgressCallback", progress));
        }
      })
    }
  } catch (err) {
    console.log(err)
  }
})

ipcMain.handle('sendDownloadInformation', function (events, namespace, funName, ...args) {
  return downloadModules[namespace][funName](...args)
})

ipcMain.handle('getDeviceId', async function () {
  const result = await getDeviceId()
  return result
})

ipcMain.handle('getAllOtherWebContentsID', function (event) {
  const webContentsList = webContents.getAllWebContents()
  return webContentsList.map(item => item.id).filter(item => item.id !== event.sender.id)
})

mountRendererLog()

// 挂载渲染进程log日志
async function mountRendererLog() {
  const status = await getSaveRendererLog()
  if (status) ipc.add('log', log)
}

require('./preload-emitter')