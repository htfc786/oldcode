from django.apps import AppConfig


class LtConfig(AppConfig):
    name = 'apps.lt'
