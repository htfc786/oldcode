<script setup>
import SelfMeet from './components/Meeting.vue'
</script>

<template>
  <SelfMeet msg="114514" />
</template>

<style scoped>
</style>
