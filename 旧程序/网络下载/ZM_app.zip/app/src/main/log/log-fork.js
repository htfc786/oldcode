const path = require('path')
const logRootPath = process.argv[2]
const errorPath = path.join(logRootPath, 'error.log')
const { configure, getLogger } = require("log4js");
configure({
  appenders: {
    emergencies: { type: "file", filename: errorPath, maxLogSize: 1024 * 1024 * 5, keepFileExt: true },
    errors: { type: 'logLevelFilter', appender: 'emergencies', level: 'error' },
    multi: { type: 'multiFile', base: logRootPath, property: 'logged', extension: '.log', maxLogSize: 1024 * 1024 * 30, backups: 5, keepFileExt: true, compress: true }
  },
  categories: {
    default: { appenders: ['errors', 'multi'], level: "trace" },
    multi: { appenders: ['multi'], level: 'trace' }
  }
});


const logMap = {}

function getLog(logName, model) {
  if (logMap[logName]) return logMap[logName]
  const log = getLogger(model);
  log.addContext('logged', logName);
  logMap[logName] = log
  return logMap[logName]
}

function emitLogger(data) {
  try {
    if (!data.logName) data.logName = 'log'
    if (!data.model) data.model = 'default'
    const log = getLog(data.logName, data.model)
    log[data.type](data.message)
  } catch (err) {
  }
}

process.on('message', function (data) {
  // 订阅消息
  emitLogger(data)
})

process.on('uncaughtException', function (err) {
  try {
    emitLogger({
      model: 'child_process',
      type: 'error',
      message: err.stack
    })
  } catch (err) {

  }
})
