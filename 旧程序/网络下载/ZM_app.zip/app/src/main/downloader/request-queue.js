const path = require('path')
const fs = require('fs-extra')
const fetch = require('node-fetch')
const AbortController = require("abort-controller")

/**
 * 请求队列设计
 */

class RequestQueue {
  constructor(config) {
    this.queue = []
    this.max = config.max
    this.rootPath = config.rootPath
  }

  async pushQueue(proFun) {
    if (this.queue.length >= this.max) {
      await Promise.race(this.queue)
      return this.pushQueue(proFun)
    }
    let promise = proFun()
    promise
      .then(() => this.queue.splice(this.queue.indexOf(promise), 1))
      .catch(err => {
        this.queue.splice(this.queue.indexOf(promise), 1)
        console.log('add catch', err)
      })
    this.queue.push(promise)
  }

  async request(option, progress) {
    return new Promise((resolve, reject) => {
      let proFun = () => {
        try {
          const writeblePath = option.filePath
          fs.ensureDirSync(path.dirname(writeblePath))
          const controller = new AbortController()
          let length = option.currentSize ? Number(option.currentSize) : 0
          let fetchConfig = option.currentSize ? {
            signal: controller.signal,
            headers: { 'Range': `bytes=${option.currentSize}-${option.size}` },
          } : {
            signal: controller.signal,
          }
          // 大小一样，直接return
          if (option.currentSize == option.size) {
            resolve({
              url: option.url,
              fileName: option.fileName,
              filePath: writeblePath
            })
            progress(100)
            return Promise.resolve()
          }
          let pro = fetch(option.url, fetchConfig).then(result => {
            return new Promise((res, rej) => {
              // 根据result.headers进行判断是否在断点续传
              const contentRange = result.headers.get('content-range')
              const streamParams = this.getStreamParams(contentRange)
              const writeable = fs.createWriteStream(writeblePath, streamParams)

              writeable.on('error', function (err) {
                rej(err)
                reject(err)
              })
              let times = 100
              result.body.on("data", (chunk) => {
                length += chunk.length
                const percent = (length / option.size * 100).toFixed(2)
                if (progress && typeof progress === 'function' && times === 100) {
                  progress(percent)
                }
                times--
                times = times === 0 ? 100 : times
              })
                .on("error", err => {
                  rej(err)
                  reject(err)
                  writeable.end()
                })
                .pipe(writeable)
                .on('error', err => {
                  rej(err)
                  reject(err)
                })
                .on('finish', () => {
                  res({
                    url: option.url,
                    fileName: option.fileName,
                    filePath: writeblePath
                  })
                  resolve({
                    url: option.url,
                    fileName: option.fileName,
                    filePath: writeblePath
                  })
                  progress(100)
                })
                .on('close', () => {
                  res({
                    url: option.url,
                    fileName: option.fileName,
                    filePath: writeblePath
                  })
                  resolve({
                    url: option.url,
                    fileName: option.fileName,
                    filePath: writeblePath
                  })
                })
            })
          }).catch(err => {
            reject(err)
            throw err
          })
          pro.controller = controller
          pro.option = option
          pro.url = option.url
          pro.fileName = option.fileName
          return pro
        } catch (err) {
          reject(err)
          return Promise.resolve()
        }
      }
      this.pushQueue(proFun)
    })
  }

  getStreamParams(contentRange) {
    try {
      if (!contentRange) return { flags: 'w' }
      const match = contentRange.match(/bytes ([\d]*)-([\d]*)\//)
      return match ? { flags: 'w', start: Number(match[1]) } : { flags: 'a+' }
    } catch (err) {
      return { flags: 'w' }
    }
  }

  async abort(fileName) {
    // 暂停下载
    console.log(`暂停下载${fileName}`)
    this.queue.map(item => {
      if (item.fileName === fileName) {
        item.controller.abort()
      }
    })
  }

  async abortAll() {
    this.queue.map(item => {
      item.controller.abort()
    })
  }

  requestHead(url) {
    return fetch(url, {
      method: 'head'
    }).then(res => {
      if (res.ok) {
        return {
          size: res.headers.get('content-length'),
          etag: res.headers.get('etag'),
          contentMd5: res.headers.get('content-md5'),
          acceptRanges: res.headers.get('accept-ranges'),
          url: url
        }
      } else {
        throw new Error(`请求错误，状态码${res.status}，原因${res.statusText}`)
      }
    })
  }
}

module.exports = RequestQueue