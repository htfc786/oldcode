/** appname */
const AppName = {
  teacher: "掌门好老师",
  student: "掌门1对1辅导",
  sales: "掌门销售"
}

/** 日志上报地址 */
const accUrlMap = {
  test: "%69%2D%74%65%73%74%2E%7A%6D%6C%65%61%72%6E%2E%63%6F%6D",
  uat: "%69%2E%75%61%74%2E%7A%6D%6F%70%73%2E%63%63",
  prod: "%69%2E%7A%6D%6C%65%61%72%6E%2E%63%6F%6D"
};

/** web页面主域名 */
const domainMap = {
  test: "%78%2D%63%68%61%74%2D%74%65%73%74%2E%7A%6D%6C%65%61%72%6E%2E%63%6F%6D",
  uat: "%63%68%61%74%2E%75%61%74%2E%7A%6D%6F%70%73%2E%63%63",
  prod: "%63%68%61%74%2E%7A%6D%6C%65%61%72%6E%2E%63%6F%6D"
};

/** 灰度api接口 */
const grayMap = {
  'test': 'https://appapi-test.zmlearn.com/gray-plan/api/grayApi/toc/gray/findGrayEffectByCodeAndParam',
  'uat': 'https://app.uat.zmops.cc/gray-plan/api/grayApi/toc/gray/findGrayEffectByCodeAndParam',
  'prod': 'https://appapi.zmlearn.com/gray-plan/api/grayApi/toc/gray/findGrayEffectByCodeAndParam',
}

/** 灰度api接口 */
const planMap = {
  'test': 'https://appapi-test.zmlearn.com/gray-plan/api/grayApi/toc/plan/findPlanByCodeAndParam',
  'uat': 'https://app.uat.zmops.cc/gray-plan/api/grayApi/toc/plan/findPlanByCodeAndParam',
  'prod': 'https://appapi.zmlearn.com/gray-plan/api/grayApi/toc/plan/findPlanByCodeAndParam',
}

/** 灰度code */
const grayCode = {
  GRAY_1v1_MONITOR: 'GRAY_1v1_MONITOR', // 开启性能监控策略
  PLAN_1v1_EXE_UPDATE: 'PLAN_1v1_EXE_UPDATE', // 强制升级策略
  GRAY_1v1_UPLOAD_LOG: 'GRAY_1v1_UPLOAD_LOG', // 本地日志上报策略
  GRAY_1v1_WRITE_RENDERER_LOG: 'GRAY_1v1_WRITE_RENDERER_LOG' // 渲染进程写本地日志策略
}

const statusCode = {
  VIRTUAL_BG_STATUS: 'virtualBgStatus', // 虚拟背景status
}

const defaultStatus = {
  [statusCode.VIRTUAL_BG_STATUS]: {
    status: -2,
    extra: {}
  }
}

module.exports = {
  AppName,
  accUrlMap,
  domainMap,
  grayMap,
  planMap,
  grayCode,
  statusCode,
  defaultStatus
}