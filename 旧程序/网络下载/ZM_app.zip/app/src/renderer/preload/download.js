const RendererEmitter = require('../ipc/ipc-preload')
const emitter = new RendererEmitter('preloadJs')

function download(url, fileName) {
  return emitter.ipcInvoke('download', url, fileName)
}


module.exports = { download }