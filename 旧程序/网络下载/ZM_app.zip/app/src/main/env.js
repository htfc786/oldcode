/**
 * 初始化全局变量
 */
const path = require("path");
const { app } = require("electron");
const config = require("../../config.json");
const { version, resourceVersion } = require("../../package.json");
const preloadPath = path.join(__dirname, '../renderer/preload/preload.js')
const { AppName, accUrlMap, domainMap } = require('../common/constants')
const { getDate } = require('../common/utils')

/**
 * 初始化全局环境
 */
function initEnvironment() {
  const baseConfig = {
    appName: AppName[config.userType],
    env: config.env,
    accUrl: decodeURI(`https://${accUrlMap[config.env]}/tracker/recordBatch`),
    domain: decodeURI(`https://${domainMap[config.env]}`),
    preloadPath: preloadPath,
    version: version,
    autoPreload: true,
    resourceVersion: resourceVersion,
    rootPath: app.getAppPath(),
    autoPreload: true,
    logFolder: createLogFolder(),
    userId: '',
  }
  global.environment = Object.assign({}, baseConfig, config)
}

function createLogFolder() {
  const date = getDate()
  const time = new Date().getTime().toString()
  return `${date}-${time}`
}


initEnvironment()