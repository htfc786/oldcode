const fetch = require('node-fetch')
const { grayMap, planMap } = require('../common/constants')

// 基础配置
const baseQueryParam = {
  grayCode: '',
  map: {
    version: global.environment.version,
    resourceVersion: global.environment.resourceVersion,
  }
}

function getGray(option) {
  option = Object.assign({}, baseQueryParam, option)
  const grayUrl = grayMap[global.environment.env]
  return fetch(grayUrl, {
    method: 'POST',
    timeout: 5000,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(option)
  })
    .then(res => {
      if (res && res.status === 200) {
        return res.json()
      } else {
        throw new Error(`http请求错误状态码：${res.status},错误信息：${res.statusText}`)
      }
    })
    .then(res => {
      console.log(res)
      if (res.code !== '0') {
        throw new Error(`服务端错误：${res.code},错误信息：${res.message}`)
      }
      return res.data
    })
}

function getPlan(option) {
  option = Object.assign({}, baseQueryParam, option)
  const grayUrl = planMap[global.environment.env]
  return fetch(grayUrl, {
    method: 'POST',
    timeout: 5000,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(option)
  })
    .then(res => {
      if (res && res.status === 200) {
        return res.json()
      } else {
        throw new Error(`http请求错误状态码：${res.status},错误信息：${res.statusText}`)
      }
    })
    .then(res => {
      console.log(res)
      if (res.code !== '0') {
        throw new Error(`服务端错误：${res.code},错误信息：${res.message}`)
      }
      return res.data
    })
}

module.exports = { getGray, getPlan }