const RendererEmitter = require('../ipc/ipc-preload')
const emitter = new RendererEmitter('preloadJs')


/**
 * emitter
 * const emit = new IpcEmit('test')
 * emit.emit('test'), emit.on('')
 */
class ShareData {
  constructor() {
    // 初始化哦
    this.emitMap = {}
    this.init()
  }

  init() {
    emitter.on('setShareData', (prop, value) => {
      if (this.emitMap[prop]) {
        this.emitMap[prop].forEach(fun => {
          fun(value)
        });
      }
    })
  }

  watch(prop, fun) {
    if (this.emitMap[prop]) {
      this.emitMap[prop].push(fun)
    } else {
      this.emitMap[prop] = [fun]
    }
  }

  set(prop, value) {
    emitter.ipcSend('setShareData', prop, value)
  }

  fetch(prop) {
    return emitter.ipcInvoke('getShareData', prop)
  }

  unwatch(prop, callback) {
    this.emitMap[prop].splice(this.emitMap[prop].indexOf(callback), 1)
  }
}

const shareData = new ShareData()


module.exports = {
  shareData
}