// 监听cpu信息
const { ipcRenderer, webFrame, remote } = require('electron')
const windowManager = remote.require("electron-window-manager");
const winName = windowManager.getCurrent().name
const winId = remote.getCurrentWindow().id


let timer = null

function startMonitor() {
  if (timer) return
  timer = setInterval(() => {
    sendMsg()
  }, 2000);
}

function stopMonitor() {
  if (timer) {
    clearInterval(timer)
    timer = null
  }
}

// 获取进程的信息
function sendMsg() {
  console.time('asd')
  const memory = process.memoryUsage()
  const resources = webFrame.getResourceUsage()
  const perMemory = performance.memory
  console.timeEnd('asd')
  send('log', {
    logName: 'performance',
    model: 'renderer',
    msg: JSON.stringify({
      memory: memory,
      resources: resources,
      path: location.href,
      perMemory: perMemory,
      winName: winName,
      winId: winId,
      code: 'renderer-performance',
    })
  })
}

function send(funName, ...args) {
  const { ipcRenderer } = top.require('electron')
  ipcRenderer.send('__libraryElectron__', funName, ...args)
}

function initMonitor() {
  ipcRenderer.invoke('check-if-open-monitor').then(monitorStatus => {
    console.log('monitorStatus', monitorStatus)
    if (monitorStatus) startMonitor()
  })

  ipcRenderer.on('renderer-preload', function (event, monitorStatus) {
    monitorStatus ? startMonitor() : stopMonitor()
  })
}

module.exports = {
  initMonitor
}