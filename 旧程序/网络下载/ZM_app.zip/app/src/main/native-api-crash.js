/**
 * 处理原生调用崩溃问题
 * 1. recordNativeApiCall：提供web端通知调用原生api ，push进内存调用队列（调用队列是内存记录，不写本地只记录当前客户端生命周期）
 * 2. recordNativeApiWhenCrash：如有崩溃从native调用队列取出10秒内崩溃的调用函数，生成崩溃记录写入本地数据，单独写崩溃文件即可（fs），格式如下 {crashNativeApi: 'getDeviceInfo', crashInfo: [{namespace,level,url,crashTime}]}
 * 3. getNativeApiCrashInfo：提供web端查询crash接口功能，返回数据{count: 2, crashInfo: [{namespace,level,url,crashTime}, {namespace,level,url,crashTime}]}
 */
const fs = require('fs-extra')
const path = require('path')
const { app } = require('electron')
const RECORD_CRASH_TIME = 10000;
const NAITVE_CRASH_LOG_NAME = 'nativeCrash.json'
const userDataPath = app.getPath('userData')
const nativeCrashLogPath = path.join(userDataPath, NAITVE_CRASH_LOG_NAME)
const { sendInfo, logDebug } = require('./log/index')
const { storage } = require('node-environment')
let naticeApiCallStack = []

/**
 * 调用原生api
 * @param {object} option 
 */
function recordNativeApiCall(option) {
  logDebug('native api 调用', option)
  option.callTime = new Date()
  naticeApiCallStack.push(option)
}

function getCrashLevel(count) {
  const crashLevelConfig = storage.getItem('crashLevelConfig', [3, 6, 9, 12])
  for (let i = 0; i < crashLevelConfig.length; i++) {
    if (count <= crashLevelConfig[i]) {
      return i
    }
  }
  return crashLevelConfig.length
}


function fixData(array) {
  let newArray = []
  for (let i = 0; i < array.length; i++) {
    const index = getActionNameSpace(newArray, array[i].action, array[i].namespace)
    if (index > -1) {
      newArray[index] = {
        crashCount: newArray[index].crashCount + 1,
        action: array[i].action,
        namespace: array[i].namespace,
        crashLevel: getCrashLevel(newArray[index].crashCount + 1),
        triggerUrl: array[i].triggerUrl,
        lastCrashTime: array[i].crashTime,
        lastCallTime: array[i].callTime,
      }
    } else {
      newArray.push({
        crashCount: 1,
        action: array[i].action,
        namespace: array[i].namespace,
        crashLevel: getCrashLevel(1),
        triggerUrl: array[i].triggerUrl,
        lastCrashTime: array[i].crashTime,
        lastCallTime: array[i].callTime,
      })
    }
  }
  return newArray
}

function getActionNameSpace(array, action, namespace) {
  let index = -1;
  array.forEach((item, key) => {
    if (item.action === action && item.namespace === namespace) {
      index = key
    }
  })
  return index
}

/**
 * 获取api崩溃信息
 * @param {string} apiName 
 */
async function getNativeApiCrashInfo(option) {
  option = option || {}
  option.crashSection = option.crashSection || 1
  let data = await getCrashLog()
  data = data.filter(item => (new Date() - new Date(item.crashTime)) < 3600000 * option.crashSection)
  // 如果有action和namespace
  let resultData = []
  if (option.action && option.namespace) {
    resultData = data.filter(item => item.action === option.action && item.namespace === option.namespace)
  } else if (option.action) {
    resultData = data.filter(item => item.action === option.action)
  } else if (option.namespace) {
    resultData = data.filter(item => item.namespace === option.namespace)
  } else {
    resultData = data
  }
  const res = fixData(resultData)
  logDebug('native api 崩溃信息获取', option, res)
  return res
}

function setCrashLog(data) {
  return fs.writeJSON(nativeCrashLogPath, data)
}

function getCrashLog() {
  if (fs.existsSync(nativeCrashLogPath)) {
    return fs.readJSON(nativeCrashLogPath)
  } else {
    return []
  }
}


/**
 * 崩溃时记录调用函数到本地
 */
async function recordNativeApiWhenCrash() {
  const crashTime = new Date()
  const matchList = naticeApiCallStack.filter(item => crashTime - item.callTime < RECORD_CRASH_TIME)
  matchList.forEach(item => item.crashTime = crashTime)
  // 如果有写本地
  if (matchList.length) {
    logDebug('native api call list', matchList)
    sendInfo('recordNativeApiWhenCrash', matchList)
    const list = await getCrashLog()
    logDebug('list', list)
    list.push(...matchList)
    await setCrashLog(list)
  }
  // 清空
  naticeApiCallStack = []
}

module.exports = {
  recordNativeApiCall,
  getNativeApiCrashInfo,
  recordNativeApiWhenCrash
}