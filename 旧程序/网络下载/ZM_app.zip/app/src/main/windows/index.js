/**
 * 窗口控制
 */


class Window {
  constructor() {
    this.windowMap = {}
  }

  open(option) {
    if (this.windowMap[option.name]) return this.windowMap[option.name]
    const { BrowserWindow } = require('electron')
    const win = new BrowserWindow(option.config)

    if (option.webview) {
      const path = require('path')
      console.log(encodeURI(option.url))
      const filePath = path.join(__dirname, `index.html`)
      const url = `file://${filePath}?url=${option.url}`
      win.loadURL(url)
    } else {
      win.loadURL(option.url)
    }
    this.windowMap[option.name] = {
      name: option.name,
      win: win
    }

    // 开启调试模式
    win.webContents.on('before-input-event', (event, input) => {
      if (global.environment.debug && input.control && input.key.toLowerCase() === 'd') {
        win.webContents.openDevTools()
      }
    })



    return this.windowMap[option.name]
  }



}

module.exports = new Window()


