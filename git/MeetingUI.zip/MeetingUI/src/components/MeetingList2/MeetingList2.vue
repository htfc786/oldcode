<script>
export default {
  props: {
    
  },
}
</script>

<template>
  <!--参会人员列表 有摄像头-->
  <div class="meeting-list2">
    
  </div>
</template>

<style scoped>
.meeting-list2 {
  background-color: rgb(0,0,0);
  height: 100%;
}
</style>