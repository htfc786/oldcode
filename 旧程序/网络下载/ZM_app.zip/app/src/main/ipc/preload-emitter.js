const MainEmitter = require('./ipc-emitter')
const emitter = new MainEmitter('preloadJs')
const windowManager = require('electron-window-manager')
const { BrowserWindow, shell } = require('electron')
const emitters = new MainEmitter('toast')
const { setStatus, getStatus, setData, getData } = require('../status')
const { logDebug } = require('../log')
const { recordNativeApiCall, getNativeApiCrashInfo, getAllNativeApiCrashInfo } = require('../native-api-crash')


emitter.ipcOn('setShareData', function (event, ...args) {
  const [prop, value] = args
  const oldValue = windowManager.sharedData.fetch(prop)
  if (oldValue !== value) {
    windowManager.sharedData.set(prop, value)
    emitter.emit('setShareData', ...args)
  }
})

emitter.ipcHandle('getShareData', function (event, prop) {
  return windowManager.sharedData.fetch(prop)
})

emitter.ipcHandle('download', async function (event, downloadUrl, fileName) {
  fileName = fileName ? fileName : downloadUrl.split('/').pop()
  const { downLoadResource } = require('../download')
  const { dialog } = require('electron')
  const res = await dialog.showSaveDialog({ defaultPath: fileName })
  return res.canceled === false ?
    downLoadResource(downloadUrl, res.filePath) :
    Promise.reject('用户主动取消下载')
})

emitter.ipcOn('showResource', function (event, ...args) {
  // 打开window窗口
  const [url, type, name] = args
  const path = require('path')
  const toastPath = path.join(__dirname, '../../renderer/windows/toast/index.html')
  const toastUrl = `file://${toastPath}`
  let toast = windowManager.get("toast");
  if (toast) {
    emitters.emitRenderer('location-resources', encodeURI(url), type, name)
    toast.object.show()
  } else {
    toast = windowManager.open(
      "toast",
      '展示页面',
      toastUrl,
      false,
      {
        resizable: true,
        frame: false,
        center: true,
        webPreferences: {
          webSecurity: false,
          nodeIntegration: true
        }
      }
    );
    // 加载完毕后执行脚本
    toast.object.webContents.on('did-finish-load', function () {
      emitters.emitRenderer('location-resources', encodeURI(url), type, name)
    })
    // 跳转直接在浏览器里打开
    toast.object.webContents.on('new-window', function (event, url) {
      event.preventDefault()
      shell.openExternal(url)
    })
    toast.object.webContents.on('before-input-event', (event, input) => {
      if (global.environment.debug && input.control && input.key.toLowerCase() === 'd') {
        toast.object.webContents.openDevTools()
      }
    })
  }
  // toast.object.webContents.openDevTools()
})


emitter.ipcOn('currentWinRun', function (event, ...args) {
  const win = BrowserWindow.fromWebContents(event.sender)
  const [method, ...arg] = args
  win[method](...arg)
})

emitter.ipcHandle('currentWinGet', function (event, ...args) {
  const win = BrowserWindow.fromWebContents(event.sender)
  const [method, ...arg] = args
  return win[method](...arg)
})

emitter.ipcHandle('getStatus', function (event, statusName, status, extra) {
  return getStatus(statusName, status, extra)
})

emitter.ipcHandle('setStatus', function (event, statusName, status, extra) {
  return setStatus(statusName, status, extra)
})

emitter.ipcHandle('getData', function (event, name) {
  logDebug('getData', name)
  return getData(name)
})

emitter.ipcHandle('setData', function (event, name, value) {
  logDebug('setData', name, value)
  return setData(name, value)
})

emitter.ipcOn('recordNativeApiCall', function (event, option) {
  recordNativeApiCall(option)
})

emitter.ipcHandle('getNativeApiCrashInfo', function (event, apiName) {
  return getNativeApiCrashInfo(apiName)
})