// 下载资源类

const fs = require("fs-extra");
const zlib = require("zlib");
const tar = require("tar-fs");
const crypto = require("crypto");
const fetch = require("node-fetch");

/**
 * 单个url资源包的下载
 * @param {string} zipResourcePath 请求路径
 * @param {string} downLoadResourcePath 下载路径
 */
function downLoadResource(zipResourcePath, downLoadResourcePath) {
  return new Promise((resolve, reject) => {
    try {
      fetch(zipResourcePath, {
        timeout: 10000,
        headers: {
          "cache-control": "no-cache"
        }
      })
        .then(res => {
          if (res.status !== 200) {
            throw new Error(
              `请求资源${zipResourcePath}有误，错误代码${res.status}-${res.statusText}`
            );
          }
          res.body
            .pipe(fs.createWriteStream(downLoadResourcePath))
            .on("error", err => reject(err))
            .on("finish", () => resolve());
        })
        .catch(err => reject(err));
    } catch (err) {
      reject(err);
    }
  });
}

/**
 * 检查下载的文件是否完整
 * @param {string} filePath 文件路径
 * @param {*} sha512 512的hash值
 */
function whetherCompleteness(filePath, sha512) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash("sha512");
    fs.readFile(filePath, (err, data) => {
      if (err) {
        reject(err);
        return;
      }
      try {
        hash.update(data);
        const mainSha512 = hash.digest("hex");
        resolve(sha512 === mainSha512);
      } catch (err) {
        reject(err);
      }
    });
  });
}

/**
 * 解压文件
 * @param {string} filePath 要解压的文件路径
 * @param {string} outPath 解压到的路径
 */
exports.unCompressResource = function (filePath, outPath) {
  return new Promise((resolve, reject) => {
    try {
      fs.createReadStream(filePath)
        .on("error", function (error) {
          reject(error);
        })
        .pipe(zlib.createUnzip())
        .on("error", function (error) {
          reject(error);
        })
        .pipe(
          tar.extract(outPath, {
            readable: true,
            writable: true
          })
        )
        .on("error", function (error) {
          reject(error);
        })
        .on("finish", () => {
          resolve();
        });
    } catch (err) {
      reject(err);
    }
  });
};

exports.download = async function (option) {
  const { url, hash, savePath } = option;
  await downLoadResource(url, savePath);
  const completeness = await whetherCompleteness(savePath, hash);
  if (!completeness) throw new Error("文件校验不通过！");
};

exports.downLoadResource = downLoadResource
