/**
 * 客户端status管理
 */

const RendererEmitter = require('../ipc/ipc-preload')
const emitter = new RendererEmitter('preloadJs')

function getStatus(statusName, status, extra) {
  return emitter.ipcInvoke('getStatus', statusName, status, extra)
}

function setStatus(statusName, status, extra) {
  return emitter.ipcInvoke('setStatus', statusName, status, extra)
}

function getData(name) {
  return emitter.ipcInvoke('getData', name)
}

function setData(name, value) {
  return emitter.ipcInvoke('setData', name, value)
}


module.exports = {
  getStatus,
  setStatus,
  getData,
  setData
}