const path = require("path");
const fs = require("fs-extra");
const Pack = require('./pack');
const { app } = require('electron');
const fetch = require('node-fetch');
const { version, resourceVersion } = require('../../../package')
const { sendError, sendInfo } = require('../log/index')

// 解压缩后的目录路径
const updatePath = path.join(global.environment.rootPath, "../update");
// 解压成功状态文件
const finishPath = path.join(updatePath, "update.json");
// 初始化package
const pack = new Pack({
  updatePath: updatePath,
  rootPath: path.dirname(app.getPath('exe'))
})

// 当前的更新状态
const stateType = {
  Idle: "Idle",
  Updating: "Updating",
  WaitRelaunch: "WaitRelaunch",
  UpdateFailed: "UpdateFailed"
};

// 接口返回信息
const state = {
  type: stateType.Idle,
  msg: "准备更新！",
  err: ""
};

exports.checkForUpdates = async function (option) {
  // web端老版本调用去掉
  if (!option.type) return
  if (state.type === stateType.Updating) {
    return state;
  }
  if (option.type === 'rollback') {
    await setRollback();
    return state;
  }
  if (state.type === stateType.WaitRelaunch) {
    const latest = await checkIfLatest(option);
    return latest ? state : startUpdates(option);
  } else {
    return startUpdates(option);
  }
};

exports.checkUpdateState = function () {
  return state;
};

exports.finishUpdate = async function () {
  const { type, updateConfig, rollbackConfig } = getUpdateJsonSync();
  const config = type === "update" ? updateConfig : rollbackConfig
  try {
    // 确定是否需要升级，不需要就直接返回
    const needUpdate = needFinishUpdate(type, config);
    if (!needUpdate) return false;

    // 检查磁盘空间是否够用
    const noSpace = await checkoutDiskSpace(type, config)
    if (noSpace) {
      sendAcc('no-disk-space', {
        msg: '磁盘空间不足！',
        ruleId: config.ruleId,
        type: type,
        timeStamp: config.timeStamp
      })
      return false;
    }

    sendAcc('needFinishUpdate', {
      msg: '开始替换app文件夹！',
      ruleId: config.ruleId,
      type: type,
      timeStamp: config.timeStamp
    })
    // 根据类型做替换或回滚
    type === 'update' ?
      update(config) :
      rollback(config)

    await sendInfo('updateFinishedSuccess', JSON.stringify({
      msg: '替换app文件夹成功！',
      ruleId: config.ruleId,
      type: type,
      timeStamp: config.timeStamp
    }, null, 2), true)
    return true;
  } catch (err) {
    // 失败就要删除备份文件
    sendAcc('updateFinishedError', {
      msg: '升级替换失败，从老版本启动！',
      ruleId: config.ruleId,
      type: type,
      timeStamp: config.timeStamp
    }, err.stack)
    throw err;
  }
};

exports.checkUpdate = async function (option) {
  let res = await fetchUpdate(option)
  // 开启更新
  if (res.upgradeType === 1 && res.downlaodUrl && res.sourceMD5Signature) {
    checkForUpdates({
      type: 'update',
      ruleId: res.ruleId,
      url: res.downlaodUrl,
      sha512: res.sourceMD5Signature,
      userId: option.userId,
      targetVersion: '',
      targetResourceVersion: res.targetVersion
    })
  }
  if (res.type === 'rollback') {
    checkForUpdates({
      type: "rollback"
    })
  }
}

function fetchUpdate(option) {
  const checkUpdateApi = `${global.environment.domain}/gateway/zmc-client-upgrade/upgradeRule/versionCheck?access_token=${option.access_token}`
  return fetch(checkUpdateApi, {
    method: 'POST',
    timeout: 3000,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(option)
  })
    .then(res => {
      if (res && res.status === 200) {
        return res.json()
      } else {
        throw new Error(`http请求错误状态码：${res.status},错误信息：${res.statusText}`)
      }
    })
    .then(res => {
      if (res.code !== '0') {
        throw new Error(`服务端错误：${res.code},错误信息：${res.message}`)
      }
      return res.data
    })
}

/**
 * 检查磁盘空间是否够用
 */
async function checkoutDiskSpace(type, config) {
  try {
    const si = require('systeminformation');
    // 确定当前安装目录
    let diskName = global.environment.rootPath.split(':')
    diskName = `${diskName[0]}:`
    let data = await si.fsSize()
    data = data.filter(item => item.fs === diskName)
    data = data[0]
    // 定义最小磁盘空间大小为50M
    const minDiskSize = 50 * 1024 * 1024
    return data.size - data.used < minDiskSize
  } catch (err) {
    sendAcc('checkoutDiskSpaceError', {
      msg: '检查磁盘空间失败！',
      ruleId: config.ruleId,
      type: type,
      timeStamp: config.timeStamp
    }, err.stack)
    return false
  }
}

function update(config) {
  // runAsUpdate
  let backupPackageName = pack.runAsUpdate(config.packageName)
  const option = {
    type: null,
    rollbackConfig: {
      backupVersion: version,
      backupResourceVersion: resourceVersion,
      url: config.url,
      sha512: config.sha512,
      timeStamp: config.timeStamp,
      ruleId: config.ruleId,
      packageName: backupPackageName
    }
  }
  setUpdateJsonSync(option);
  updateResourceVersion(config.targetVersion, config.targetResourceVersion)
}

function rollback(config) {
  // runAsRollback
  pack.runAsRollback(config.packageName)
  fs.removeSync(finishPath);
  updateResourceVersion(config.backupVersion, config.backupResourceVersion)
}

function setState(type, err) {
  state.type = type;
  switch (type) {
    case stateType.Idle:
      state.msg = "更新程序未启动！";
      state.err = "";
      break;
    case stateType.Updating:
      state.msg = "更新程序运行中！";
      state.err = "";
      break;
    case stateType.WaitRelaunch:
      state.msg = "操作完成，等待重启！";
      state.err = "";
      break;
    case stateType.UpdateFailed:
      state.msg = "更新过程发生错误！";
      state.err = err;
      break;
  }
  return state;
}

async function setRollback() {
  setState(stateType.Updating);
  try {
    const config = await getUpdateJson();
    config.type = "rollback";
    await setUpdateJson(config);
    setState(stateType.WaitRelaunch);
  } catch (err) {
    setState(stateType.UpdateFailed, err);
  }
}

function needFinishUpdate(type, config) {
  return type && config && pack.ifExist(config.packageName)
}

function checkIfLatest(option) {
  return getUpdateJson()
    .then(data => data.updateConfig.sha512 === option.sha512)
    .catch(() => false);
}

/**
 * 检查更新
 * @param {string} option 资源名称
 */
async function startUpdates(option) {
  // 增加开始埋点
  option.timeStamp = new Date().getTime();
  sendAcc('startUpdates', {
    msg: '开始更新！',
    ruleId: option.ruleId,
    type: option.type,
    timeStamp: option.timeStamp
  })
  // 开始更新，更改更新状态
  setState(stateType.Updating);
  return downloadAndUnCompress(option)
    .then(() => {
      // 更新状态
      sendAcc('downloadAndUnCompressSuccess', {
        msg: '下载解压完成，等待重启！',
        ruleId: option.ruleId,
        type: option.type,
        timeStamp: option.timeStamp
      })
      return setState(stateType.WaitRelaunch);
    })
    .catch(err => {
      sendAcc('downloadAndUnCompressError', {
        msg: '升级错误，下载或解压失败！',
        ruleId: option.ruleId,
        type: option.type,
        timeStamp: option.timeStamp
      }, err.stack)
      setState(stateType.UpdateFailed);
      throw state;
    });
}


async function downloadAndUnCompress(option) {
  let packageName = await pack.downloadPackage({
    url: option.url,
    sha512: option.sha512
  })
  // 解压缩成功写文件解压成功文件
  await writeUpdateJson({
    type: "update",
    updateConfig: {
      targetVersion: option.targetVersion,
      targetResourceVersion: option.targetResourceVersion,
      url: option.url,
      sha512: option.sha512,
      timeStamp: option.timeStamp,
      ruleId: option.ruleId,
      packageName: packageName
    }
  });
}

// 解压成功写配置文件
async function writeUpdateJson(option) {
  const updateJson = await getUpdateJson();
  // 如果有上次更新备份删除上次更新的备份
  try {
    pack.deletePackage(updateJson.rollbackConfig.packageName)
  } catch (err) {
    console.log(err)
  }
  return setUpdateJson(option);
}

function getUpdateJson() {
  if (fs.existsSync(finishPath)) {
    return fs.readJson(finishPath);
  } else {
    return Promise.resolve({});
  }
}

/**
 * 同步读取，electron的bug异步读取在cpu不足的情况下竟然耗时很久
 */
function getUpdateJsonSync() {
  try {
    if (fs.existsSync(finishPath)) {
      return fs.readJSONSync(finishPath)
    } else {
      return {}
    }
  } catch (err) {
    sendError("readJSONSyncError", "读取UpdateJson失败！", err);
    // 删除文件
    try {
      fs.removeSync(finishPath)
    } catch (err) { }
    return {}
  }
}


function setUpdateJsonSync(config) {
  return fs.writeJsonSync(finishPath, config, { spaces: 2 });
}


function setUpdateJson(config) {
  return fs.writeJson(finishPath, config, { spaces: 2 });
}

function updateResourceVersion(version, resourceVersion) {
  if (!version && !resourceVersion) {
    return
  }
  const packagePath = path.join(__dirname, '../../../package.json')
  const package = fs.readJSONSync(packagePath)
  if (package.version === version && package.resourceVersion === resourceVersion) {
    return
  }
  if (version) {
    package.version = version
  }
  if (resourceVersion) {
    package.resourceVersion = resourceVersion
  }
  fs.writeJSONSync(packagePath, package, { spaces: 2 })
}

async function sendAcc(code, option, err) {
  try {
    err ?
      await sendError(code, JSON.stringify(option, null, 2), err) :
      await sendInfo(code, JSON.stringify(option, null, 2))
  } catch (err) { }
}
