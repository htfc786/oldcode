from django.apps import AppConfig


class TjbusConfig(AppConfig):
    name = 'apps.tjbus'
