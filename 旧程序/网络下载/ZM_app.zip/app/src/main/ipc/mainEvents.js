const MainEmitter = require('./ipc-emitter')
const mainEvents = new MainEmitter('insteadOfRemoteCall')
module.exports = mainEvents