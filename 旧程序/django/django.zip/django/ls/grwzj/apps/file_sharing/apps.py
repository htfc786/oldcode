from django.apps import AppConfig


class FileSharingConfig(AppConfig):
    name = 'apps.file_sharing'
