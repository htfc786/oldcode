from django.apps import AppConfig


class PythonxclassConfig(AppConfig):
    name = 'pythonxclass'
