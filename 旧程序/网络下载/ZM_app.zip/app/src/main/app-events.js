const { app } = require('electron')
const { sendInfo } = require('./log/index')
const { quitIfNoWindow } = require('./window')
const { handleGpuCrash } = require('./gpu-strategy')
const { handleRendererProcessCrash } = require('./error-report')

// 挂载app函数
app.on("window-all-closed", quitIfNoWindow);
app.on("before-quit", async () => await sendInfo("appQuit", "用户退出程序", true));
app.on("gpu-process-crashed", handleGpuCrash);
app.on("renderer-process-crashed", handleRendererProcessCrash);
