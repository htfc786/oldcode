
const { app, crashReporter } = require("electron");
const { getDeviceId, storage } = require("node-environment");
const { sendError, sendInfo, logDebug } = require('./log/index')
const { uploadLogWhenCrashed } = require('./log/upload-log')
const { getCrashPcInfo } = require('./monitor')
const { virtualBgStatusStrategy } = require('./status')
const { recordNativeApiWhenCrash } = require('./native-api-crash')
const userId = storage.getItem('userId');

async function reportCrash() {
  try {
    logDebug('开启crash reporter')
    const deviceId = await getDeviceId().catch(err => '')
    crashReporter.start({
      companyName: "zmlearn",
      submitURL: `${global.environment.domain}/gateway/zmc-monitor/api/fill/collapse?userId=${userId}`,
      ignoreSystemCrashHandler: true,
      extra: {
        appId: global.environment.appId,
        deviceId: deviceId,
        version: global.environment.version,
        resourceVersion: global.environment.resourceVersion,
      }
    });
  } catch (err) {
    logDebug('开启crash reporter 失败')
    console.log(err)
  }
}

function catchGlobalError() {
  if (!global.environment.debug) {
    process.on("uncaughtException", function (err) {
      sendError("uncaughtException", "未捕获的错误！", err);
    });
    process.on("unhandledRejection", function (err) {
      sendError("unhandledRejection", "未捕获的promise错误！", err);
    });
  }
}

async function handleRendererProcessCrash(event, webContents, killed) {
  const currentUrl = webContents.history[webContents.currentIndex];

  const { rendererProcessCrashDialog } = require('./dialog')
  const info = getCrashPcInfo()
  // 关闭虚拟背景操作
  await virtualBgStatusStrategy()
  // 发送崩溃埋点
  await sendError("renderer-process-crashed", "渲染进程崩溃", JSON.stringify({
    currentUrl: currentUrl,
    performance: info,
  }), true);
  try {
    const ossUrl = await uploadLogWhenCrashed()
    await sendInfo("upload-crash-log-success", `上传崩溃日志成功， oss地址：${ossUrl}`, true);
  } catch (err) {
    sendError("upload-crash-log-error", "上传崩溃日志失败", err, true);
  }
  // 记录native api 崩溃信息
  recordNativeApiWhenCrash()

  let res = await rendererProcessCrashDialog()
  const pressInfo = ['刷新页面', '退出重启', '不作处理']
  await sendInfo('crash-dialog-press-status', `用户点击了${pressInfo[res.response]}`, true)
  switch (res.response) {
    case 0:
      // 刷新页面
      webContents.reload();
      break;
    case 1:
      // 退出程序
      app.relaunch()
      app.exit(0)
      break;
    case 2:
      break;
    default:
      webContents.reload();
      break;
  }
}

module.exports = {
  reportCrash,
  catchGlobalError,
  handleRendererProcessCrash
}