export default class Playre {
    constructor(name) {
        this.username = name;
        this.pokerList = [];
    }
}