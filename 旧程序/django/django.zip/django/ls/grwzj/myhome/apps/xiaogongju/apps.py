from django.apps import AppConfig


class XiaogongjuConfig(AppConfig):
    name = 'apps.xiaogongju'
