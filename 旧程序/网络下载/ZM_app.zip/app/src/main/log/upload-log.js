/**
 * 本地日志上报删除策略
 */
const fs = require('fs-extra')
const path = require('path')
const { uploadOSS } = require('../oss');
const { getDeviceId } = require("node-environment");
const { getDate, asyncStack } = require('../../common/utils')
const { logDebug, sendInfo, sendError } = require('./index')

const { app } = require("electron");
const userDataPath = app.getPath("userData");
const logPath = path.join(userDataPath, 'logs')

async function uploadLogFile(logFileName, ossUploadPath) {
  const logFileNamePath = path.join(logPath, logFileName)
  const logFileNameGzPath = path.join(logPath, `${logFileName}.tar.gz`)
  if (!fs.existsSync(logFileNamePath)) return
  // 压缩文件夹
  await gzipMain(logFileNamePath, logFileNameGzPath)
  // 上传压缩文件
  const ossUrl = await uploadOSS(logFileNameGzPath, ossUploadPath)
  deleteFile(logFileNameGzPath)
  return ossUrl
}


function deleteFile(filePath) {
  try {
    fs.removeSync(filePath)
  } catch (err) {
    logDebug('删除文件失败', err.stack)
  }
}




function gzipMain(entryPath, outPath) {
  const tar = require('tar-fs')
  const zlib = require("zlib");
  const fs = require('fs-extra')
  return new Promise((resolve, reject) => {
    tar
      .pack(entryPath)
      .on("error", function (error) {
        reject(error);
      })
      .pipe(zlib.createGzip())
      .on("error", function (error) {
        reject(error);
      })
      .pipe(fs.createWriteStream(outPath))
      .on("error", function (error) {
        reject(error);
      })
      .on("finish", function () {
        resolve();
      });
  });
}

async function getUploadLogGray() {
  const { getGray } = require('../best')
  const { grayCode } = require('../../common/constants')
  const deviceId = await getDeviceId()
  return getGray({
    grayCode: grayCode.GRAY_1v1_UPLOAD_LOG,
    map: {
      deviceId: deviceId,
      version: global.environment.version,
      resourceVersion: global.environment.resourceVersion,
    }
  })
}

/**
 * 获取当前目录下日志文件夹列表
 * @returns 
 */

function getLogsList() {
  const files = fs.readdirSync(logPath)
  return files.filter(file => {
    const filePath = path.join(logPath, file)
    const stat = fs.statSync(filePath)
    return stat.isDirectory() && /^\d*-\d*-\d*-\d*$/.test(file)
  })
}

async function upload(fileName) {
  try {
    const deviceId = await getDeviceId()
    const data = fileName.slice(0, 10)
    const uploadPath = `client_log/${data}/${deviceId}/${fileName}.tar.gz`
    let res = await uploadLogFile(fileName, uploadPath)
    deleteFile(path.join(logPath, fileName))
    sendInfo('uploadLogFileSuccess', `上传日志成功， oss地址：${res}`)
  } catch (err) {
    sendError('uploadLogFileError', '上传日志失败', err)
  }
}



async function clearLogStrategy() {
  // 删除本地文件策略
  const logList = getLogsList()
  logDebug('本地日志文件夹列表', logList)
  const shouldUploadList = logList.filter(item => item !== global.environment.logFolder)
  logDebug('需上传或删除日志列表', shouldUploadList)
  const uploadLogGray = await getUploadLogGray()
  logDebug('上传日志策略状态', uploadLogGray)
  if (uploadLogGray) {
    sendInfo('uploadLogFileStart', '触发本地日志上传')
    // 执行批量上传删除策略
    asyncStack(shouldUploadList, upload)
  } else {
    asyncStack(shouldUploadList, (fileName) => deleteFile(path.join(logPath, fileName)))
  }
}

async function uploadLogWhenCrashed() {
  const deviceId = await getDeviceId()
  const data = getDate()
  const uploadPath = `crash_log/${global.environment.env}/${data}/${deviceId}/${global.environment.logFolder}.tar.gz`
  return uploadLogFile(global.environment.logFolder, uploadPath)
}

module.exports = {
  clearLogStrategy,
  uploadLogWhenCrashed
}