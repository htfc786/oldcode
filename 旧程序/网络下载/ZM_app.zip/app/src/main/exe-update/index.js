/**
 * 强制升级策略
 */
const { logDebug } = require('../log')
const { getData } = require('../status')

/**
 * 获取强制升级策略
 */
async function getUpdateStrategy() {
  logDebug('开始获取强制升级策略')
  const { getPlan } = require('../best')
  const { getDeviceId } = require("node-environment");
  const deviceId = await getDeviceId()
  const { grayCode } = require('../../common/constants')
  const lessonType = getData('lessonType')
  const data = {
    deviceId: deviceId,
    version: global.environment.version,
    resourceVersion: global.environment.resourceVersion,
    lessonType: lessonType
  }
  logDebug('安装包升级请求参数', data)
  return getPlan({
    grayCode: grayCode.PLAN_1v1_EXE_UPDATE,
    map: data
  })
}


/**
 * 下载文件
 * @param {string} url 
 * @returns 
 */
async function downloadFile(url) {
  const Downloader = require('../downloader/downloader')
  const download = new Downloader({
    namespace: 'exeUpdate'
  })
  const fileName = url.split('/').pop()
  return download.download({
    fileName: fileName,
    url: url
  })
}

/**
 * 退出安装
 * @param {string} filePath 
 */
function quitAndInstall(filePath) {
  const { app } = require('electron')
  app.relaunch({ execPath: filePath });
  app.exit(0);
}

/**
 * 静默安装
 * @param {string} filePath 
 */
function silentInstall(filePath) {
  const fs = require('fs')
  const path = require('path')
  const childprocess = require("child_process")
  const flagName = path.basename(filePath, '.exe')
  const flagPath = path.join(path.dirname(filePath), `${flagName}.flag`)
  fs.writeFileSync(flagPath, 'flag')
  const { app } = require('electron')
  const exePath = app.getPath('exe')
  const currentPath = path.dirname(exePath)
  let updateProcess = childprocess.spawn(filePath, [
    '/verysilent',
    `/update=${flagPath}`,
    `/currentPath=${currentPath}`, // 指定当前安装路径
    //'/uninstallReg=true', // 强制更新控制面板卸载程序
    // '/creatIcons=true', // 强制生成快捷方式和图标
    '/nocloseapplications'
  ], {
    detached: true,
    stdio: ['ignore', 'ignore', 'ignore'],
    windowsVerbatimArguments: true
  },
    function (error, stdout, stderr) {
      console.log(error)
      console.log(stdout)
      console.log(stderr)
    })
  updateProcess.unref();
}



/**
 * 弹框提示
 * @returns 
 */
function showUpdateDialog() {
  const { dialog } = require('electron')
  return dialog.showMessageBox({
    type: "info",
    title: "发现新版本",
    message: "发现新版本退出客户端并安装？",
    detail: "",
    buttons: ["确定", "取消"]
  })
}



async function checkEXEUpdate() {
  const { sendInfo } = require("../log/index");
  const data = await getUpdateStrategy()
  logDebug('升级规则返回数据', data)
  const { url, slient } = data.planParam
  if (!url) return
  // 匹配到规则
  sendInfo('getUpdateStrategySuccess', '匹配到升级规则')
  const { filePath } = await downloadFile(url)
  if (!filePath) return
  // 下载成功的
  sendInfo('downloadEXEFileSuccess', '下载安装包成功')
  if (slient === '1') {
    const { isActive } = require('windows-mutex');
    // -ready是解压完成触发的
    const appMutex = `${global.environment.appMutex}-setup`
    if (isActive(appMutex)) return
    sendInfo('silentInstallStart', '触发静默安装')
    silentInstall(filePath)
  } else {
    const { response } = await showUpdateDialog()
    const res = response === 0 ? '确定' : '取消'
    await sendInfo('showUpdateDialogResult', `用户点击了${res}`, true)
    if (response === 0) quitAndInstall(filePath)
  }
}

module.exports = { checkEXEUpdate }
