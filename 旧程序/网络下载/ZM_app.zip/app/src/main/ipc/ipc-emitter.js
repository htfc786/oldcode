/**
 * ipcMain
 */

const { ipcMain, webContents } = require('electron')
const EventEmitter = require('events');


class MainEmitter extends EventEmitter {
  constructor(name) {
    super()
    name = name || 'default'
    this.emitterName = name
    this.IPCRENDERER_EMIT = `electron:renderer:${name}:emit`
    this.IPCRENDERER_SEND = `electron:renderer:${name}:send`
    this.IPCRENDERER_ON = `electron:renderer:${name}:on`
    this.INVOKE = `electron:${name}:invoke`
    this.ON = `electron:${name}:on`
    this.init()
  }

  init() {
    ipcMain.on(this.IPCRENDERER_EMIT, (event, name, ...args) => {
      this.emitMain(name, ...args)
    })
  }

  emit(name, ...args) {
    this.emitMain(name, ...args)
    this.emitRenderer(name, ...args)
  }

  emitMain(name, ...args) {
    super.emit(name, ...args)
  }

  emitRenderer(name, ...args) {
    for (let wc of webContents.getAllWebContents()) {
      wc.send(this.IPCRENDERER_ON, name, ...args)
    }
  }

  on(name, fun) {
    super.on(name, fun)
  }

  ipcOn(channel, fun) {
    channel = `${this.ON}:${channel}`
    ipcMain.on(channel, fun)
  }

  ipcHandle(channel, fun) {
    channel = `${this.INVOKE}:${channel}`
    ipcMain.handle(channel, fun)
  }
}

module.exports = MainEmitter