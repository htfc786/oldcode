/**
 * log
 * 本地log和线上log结合
 */
const { log } = require('./log')
const { serverLogInfo, serverLogError } = require('./tracking')



function logInfo(...msg) {
  msg = msg.map(item => {
    try {
      return typeof item === 'object' ? JSON.stringify(item) : item
    } catch (err) {
      return ''
    }
  })
  log({ type: 'info', msg: msg.toString() })
}

function logError(...msg) {
  msg = msg.map(item => {
    try {
      return typeof item === 'object' ? JSON.stringify(item) : item
    } catch (err) {
      return ''
    }
  })
  log({ type: 'error', msg: msg.toString() })
}

function logDebug(...msg) {
  if (global.environment.debug) {
    console.log(...msg)
    msg = msg.map(item => {
      try {
        return typeof item === 'object' ? JSON.stringify(item) : item
      } catch (err) {
        return ''
      }
    })
    log({ type: 'debug', msg: msg.toString() })
  }
}

async function sendInfo(code, msg, immediate) {
  logInfo(code, msg)
  return serverLogInfo(code, msg, immediate)
}

async function sendError(code, msg, err, immediate) {
  logError(code, msg, err)
  return serverLogError(code, msg, err, immediate)
}


module.exports = {
  sendInfo,
  sendError,
  logInfo,
  logError,
  log,
  logDebug
}