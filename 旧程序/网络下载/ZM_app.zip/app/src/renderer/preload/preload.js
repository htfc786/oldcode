const { crashReport } = require('./crash-report')
const { showResource, currentWin } = require('./window')
const { shareData } = require('./share')
const { initMonitor } = require('./monitor')
const { download } = require('./download')
const RendererEmitter = require('../ipc/ipc-preload')
const { getStatus, setStatus, setData, getData } = require('./status')
const { recordNativeApiCall, getNativeApiCrashInfo } = require('./native-api-crash')
const mainEvents = require('./main-events')

crashReport()
initMonitor()

window.electronBridge = {
  showResource,
  currentWin,
  shareData,
  RendererEmitter,
  download,
  getStatus,
  setStatus,
  setData,
  getData,
  recordNativeApiCall,
  getNativeApiCrashInfo,
  mainEvents
}
