const { globalShortcut } = require('electron')
const { showMessage } = require('./dialog')
const { logInfo } = require('./log/index')
const { getCrashPcInfo } = require('./monitor')
const windowManager = require("electron-window-manager");

// 暂时禁用
function createUploadShortcut() {
  // 创建上报快捷键
  /* const ret = globalShortcut.register('CommandOrControl+K', () => {
    // 上报日志
    getCrashPcInfo().then(res => {
      // 日志上报成功
      showMessage('日志上报成功')
    }).catch(err => {
      showMessage('日志上报失败', err.stack, 'error')
    })
  })
  if (!ret) {
    logInfo('快捷键注册失败', 'main')
  } */
}

function createDevtoolsShortcut() {
  if (global.environment.debug) {
    globalShortcut.register("CommandOrControl+D", () => {
      const homeWin = windowManager.get("home");
      const loginWin = windowManager.get("Login");
      const classWin = windowManager.get("classroom");

      if (homeWin) homeWin.object.webContents.openDevTools();
      if (loginWin) loginWin.object.webContents.openDevTools();
      if (classWin) classWin.object.webContents.openDevTools();
    });
  }
}

module.exports = {
  createUploadShortcut,
  createDevtoolsShortcut
}