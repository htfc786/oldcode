const { dialog } = require('electron')

function gpuCrashDialog() {
  return dialog.showMessageBox({
    type: "error",
    title: "GPU罢工了",
    message: "GPU无法正常使用了 : (",
    detail: "请点击“确定”关闭GPU加速，以保证客户端正常使用",
    buttons: ["确定", "取消"]
  })
}

function rendererProcessCrashDialog() {
  return dialog.showMessageBox({
    type: "error",
    title: "页面崩溃了",
    cancelId: 2,
    message: "当前页面崩溃了",
    detail: "页面崩溃了，上课时尽量关掉其他占用内存的软件，或者刷新页面重试！",
    buttons: ["刷新页面", "重启客户端", "不做处理"]
  })
}

function showMessage(msg, detail, type) {
  type = type || 'info'
  return dialog.showMessageBox({
    type: type,
    title: "提示信息",
    message: msg,
    detail: detail,
    buttons: ["确定"]
  })
}

module.exports = {
  showMessage,
  gpuCrashDialog,
  rendererProcessCrashDialog
}