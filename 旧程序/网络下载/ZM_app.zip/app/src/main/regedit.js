/**
 * 通过注册表获取信息
 */

const semver = require('semver')
const invokeLite = require("iconv-lite");
const { spawn } = require('child_process');

// 去重键
const keyList = ['DisplayIcon']
const softNameList = ['zm-student', 'zm-teacher', '掌门']
// 四大注册表地址
const uninstallPath = [
  'HKLM\\SOFTWARE\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall',
  'HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall',
  'HKCU\\SOFTWARE\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall',
  'HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall',
]

/**
 * 版本标志
 * 1. 版本大于2.2.3以上的区分老师端和学生端
 * 2. 2.2.3及以下版本不区分
 * 3. 学生端取‘1对1’关键字，老师端取‘老师’关键字
 * 4. 优客和少儿及销售归入其他
 */

function getClientType(DisplayName, DisplayVersion) {
  const keywordsList = [
    {
      keywords: '1对1',
      clientType: 'student',
    },
    {
      keywords: '老师',
      clientType: 'teacher',
    }
  ]
  let ClientType = ''
  if (semver.valid(DisplayVersion) && semver.lte(DisplayVersion, '2.2.3')) {
    ClientType = 'other'
    return ClientType
  }
  let includes = false
  keywordsList.forEach(item => {
    if (DisplayName.includes(item.keywords) && DisplayName.indexOf("少儿") === -1) {
      includes = true
      ClientType = item.clientType
    }
  })
  if (!includes) {
    ClientType = 'other'
  }
  return ClientType
}


/**
 * 列出当前客户端安装过的版本
 */
exports.listAllInstallVersion = async function () {
  let regList = await Promise.all(uninstallPath.map(v => listRegeditPathInfo(v)))
  regList = regList
    .map(item => item && item.split('\r\n\r\n'))
    .flat()
    .filter(item => {
      let include = false
      softNameList.forEach(items => {
        let hasMatch = item && item.match(/DisplayName[\s]*REG_SZ([^\r\n]*)\r\n/)
        if (hasMatch && hasMatch[1] && hasMatch[1].trim().indexOf(items) > -1) include = true
      })
      return include
    })
    .map(item => matchSingleTable(item))
  return deDuplicate(regList, keyList)
}

/**
 * 处理单条数据
 * @param {string} item 
 */
function matchSingleTable(item) {
  item = item.split('\r\n')
  let result = {
    DisplayName: '',
    DisplayIcon: '',
    UninstallString: '',
    DisplayVersion: ''
  }
  item.map(items => {
    if (items.indexOf('DisplayName') > -1) {
      result.DisplayName = items.match(/REG_SZ([\s\S]*)/)[1].trim()
    }
    if (items.indexOf('DisplayIcon') > -1) {
      result.DisplayIcon = items.match(/REG_SZ([\s\S]*)/)[1].trim()
    }
    if (items.indexOf('UninstallString') > -1) {
      result.UninstallString = items.match(/REG_SZ([\s\S]*)/)[1].trim()
    }
    if (items.indexOf('DisplayVersion') > -1) {
      result.DisplayVersion = items.match(/REG_SZ([\s\S]*)/)[1].trim()
    }
  })
  result.ClientType = getClientType(result.DisplayName, result.DisplayVersion)
  return result
}

/**
 * 根据键去重
 * @param {array} list 
 * @param {array} keyList 
 */
function deDuplicate(list, keyList) {
  // 定义去重键
  let exist = []
  return list.filter(item => {
    // 单个item
    let index = -1
    exist.forEach((v, i) => {
      let has = true
      keyList.forEach(k => {
        if (item[k] != v[k]) {
          has = false
        }
      })
      if (has) {
        index = i
      }
    })
    // 如果item已经存在
    if (index > -1) {
      return false
    } else {
      exist.push(item)
      return true
    }
  })
}

/**
 * 获取指定注册表路径的信息（无效路径或出错返回空）
 * @param {string} regeditPath 
 * @return {Promise}
 */
function listRegeditPathInfo(regeditPath) {
  return new Promise((resolve, reject) => {
    let chunks = []
    const childProcess = spawn("reg", ['query', regeditPath, '/s'])
    let { stdout, stderr } = childProcess
    stdout.on('data', function (data) {
      chunks = chunks.concat(data)
    })
    stdout.on('end', function () {
      let buffer = Buffer.concat(chunks)
      resolve(invokeLite.decode(buffer, 'gbk'))
    })
    stderr.on('data', function () {
      resolve()
    })
    childProcess.on('error', function () {
      resolve()
    })
  })
}