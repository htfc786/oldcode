from django.apps import AppConfig


class FilegxConfig(AppConfig):
    name = 'apps.filegx'
